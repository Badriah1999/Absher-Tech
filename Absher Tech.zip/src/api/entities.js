import { base44 } from './base44Client';


export const Notification = base44.entities.Notification;

export const Request = base44.entities.Request;



// auth sdk:
export const User = base44.auth;