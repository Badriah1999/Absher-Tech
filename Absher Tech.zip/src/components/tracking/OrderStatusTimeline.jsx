import React from 'react';
import { motion } from 'framer-motion';
import { Check, Clock, Package, Truck, MapPin, Building2 } from 'lucide-react';

export default function OrderStatusTimeline({ status, deliveryMethod }) {
  const branchSteps = [
    { id: 'pending', label: 'قيد المراجعة', icon: Clock, completed: true },
    { id: 'processing', label: 'جاري المعالجة', icon: Package, completed: status !== 'pending' },
    { id: 'ready_for_pickup', label: 'جاهز للاستلام', icon: Building2, completed: status === 'ready_for_pickup' || status === 'completed' },
    { id: 'completed', label: 'تم الاستلام', icon: Check, completed: status === 'completed' }
  ];

  const deliverySteps = [
    { id: 'pending', label: 'قيد المراجعة', icon: Clock, completed: true },
    { id: 'processing', label: 'جاري التجهيز', icon: Package, completed: status !== 'pending' },
    { id: 'out_for_delivery', label: 'في الطريق', icon: Truck, completed: status === 'out_for_delivery' || status === 'completed' },
    { id: 'completed', label: 'تم التوصيل', icon: Check, completed: status === 'completed' }
  ];

  const steps = deliveryMethod === 'express' ? deliverySteps : branchSteps;
  const currentStepIndex = steps.findIndex(step => step.id === status);

  return (
    <div className="bg-[#1a1a1a] rounded-3xl p-6 border border-[#2a2a2a]">
      <h3 className="text-white font-bold mb-6">حالة الطلب</h3>
      
      <div className="relative">
        {steps.map((step, index) => {
          const Icon = step.icon;
          const isCompleted = step.completed;
          const isCurrent = index === currentStepIndex;
          const isLast = index === steps.length - 1;

          return (
            <div key={step.id} className="relative">
              <div className="flex items-start gap-4">
                {/* Icon */}
                <div className="relative z-10">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: index * 0.1 }}
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${
                      isCompleted
                        ? 'bg-[#b4ff00] shadow-lg shadow-[#b4ff00]/20'
                        : isCurrent
                        ? 'bg-amber-500 shadow-lg shadow-amber-500/20'
                        : 'bg-[#2a2a2a]'
                    }`}
                  >
                    {isCompleted ? (
                      <Check className="w-6 h-6 text-black" />
                    ) : (
                      <Icon className={`w-6 h-6 ${isCurrent ? 'text-white' : 'text-gray-500'}`} />
                    )}
                  </motion.div>

                  {/* Animated pulse for current step */}
                  {isCurrent && !isCompleted && (
                    <motion.div
                      className="absolute inset-0 rounded-2xl bg-amber-500"
                      initial={{ opacity: 0.5, scale: 1 }}
                      animate={{ opacity: 0, scale: 1.5 }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    />
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 pb-8">
                  <h4 className={`font-semibold mb-1 ${
                    isCompleted ? 'text-[#b4ff00]' : isCurrent ? 'text-white' : 'text-gray-500'
                  }`}>
                    {step.label}
                  </h4>
                  {isCompleted && (
                    <p className="text-xs text-gray-400">
                      تم في {new Date().toLocaleDateString('ar-SA')}
                    </p>
                  )}
                  {isCurrent && !isCompleted && (
                    <p className="text-xs text-amber-400">جاري التنفيذ الآن...</p>
                  )}
                </div>
              </div>

              {/* Connecting Line */}
              {!isLast && (
                <div className="absolute right-6 top-12 w-0.5 h-full -z-0">
                  <div className={`w-full h-full ${isCompleted ? 'bg-[#b4ff00]' : 'bg-[#2a2a2a]'}`} />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}