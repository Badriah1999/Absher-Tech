import React from 'react';
import { motion } from 'framer-motion';
import { Building2, Clock, MapPin, Navigation, Phone, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function BranchStatus({ branch, status }) {
  const getStatusInfo = () => {
    switch (status) {
      case 'processing':
        return {
          label: 'جاري التجهيز',
          color: 'amber',
          icon: Clock,
          description: 'يتم تجهيز طلبك في الفرع حالياً'
        };
      case 'ready_for_pickup':
        return {
          label: 'جاهز للاستلام',
          color: 'green',
          icon: CheckCircle2,
          description: 'طلبك جاهز ويمكنك استلامه من الفرع'
        };
      default:
        return {
          label: 'قيد المراجعة',
          color: 'blue',
          icon: Clock,
          description: 'يتم مراجعة طلبك'
        };
    }
  };

  const statusInfo = getStatusInfo();
  const StatusIcon = statusInfo.icon;

  const branchInfo = {
    name: branch || 'فرع الرياض - العليا',
    address: 'طريق الملك فهد، حي العليا',
    phone: '+966 11 234 5678',
    workingHours: '8:00 ص - 8:00 م',
    isOpen: true,
    lat: 24.7136,
    lng: 46.6753
  };

  return (
    <div className="bg-[#1a1a1a] rounded-3xl overflow-hidden border border-[#2a2a2a]">
      {/* Status Header */}
      <div className={`p-5 border-b border-[#2a2a2a] bg-gradient-to-l ${
        statusInfo.color === 'amber' ? 'from-amber-900/20 to-amber-800/20' :
        statusInfo.color === 'green' ? 'from-green-900/20 to-green-800/20' :
        'from-blue-900/20 to-blue-800/20'
      }`}>
        <div className="flex items-center gap-4">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className={`w-14 h-14 rounded-2xl flex items-center justify-center ${
              statusInfo.color === 'amber' ? 'bg-amber-500' :
              statusInfo.color === 'green' ? 'bg-green-500' :
              'bg-blue-500'
            } shadow-lg`}
          >
            <StatusIcon className="w-7 h-7 text-white" />
          </motion.div>
          <div className="flex-1">
            <h3 className="text-white font-bold text-lg mb-1">{statusInfo.label}</h3>
            <p className="text-gray-400 text-sm">{statusInfo.description}</p>
          </div>
        </div>

        {status === 'ready_for_pickup' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-4 bg-green-500/10 border border-green-500/20 rounded-xl p-3"
          >
            <p className="text-green-400 text-sm font-semibold text-center">
              🎉 يمكنك الآن التوجه للفرع لاستلام هويتك الجديدة
            </p>
          </motion.div>
        )}
      </div>

      {/* Branch Information */}
      <div className="p-5">
        <div className="flex items-start gap-3 mb-4">
          <Building2 className="w-5 h-5 text-[#b4ff00] flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="text-white font-semibold mb-1">{branchInfo.name}</h4>
            <p className="text-gray-400 text-sm">{branchInfo.address}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-[#2a2a2a] rounded-xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <Clock className="w-4 h-4 text-purple-400" />
              <span className="text-xs text-gray-400">ساعات العمل</span>
            </div>
            <p className="text-white text-sm font-semibold">{branchInfo.workingHours}</p>
            {branchInfo.isOpen && (
              <p className="text-green-400 text-xs mt-1">• مفتوح الآن</p>
            )}
          </div>
          <div className="bg-[#2a2a2a] rounded-xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <Phone className="w-4 h-4 text-blue-400" />
              <span className="text-xs text-gray-400">الهاتف</span>
            </div>
            <a href={`tel:${branchInfo.phone}`} className="text-white text-sm font-semibold hover:text-[#b4ff00]">
              اتصال
            </a>
          </div>
        </div>

        {/* Map Image Placeholder */}
        <div className="relative h-48 rounded-2xl overflow-hidden bg-[#2a2a2a] mb-4">
          <img
            src={`https://api.mapbox.com/styles/v1/mapbox/dark-v10/static/${branchInfo.lng},${branchInfo.lat},13,0/400x300@2x?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw`}
            alt="Branch Location"
            className="w-full h-full object-cover opacity-75"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-3 left-3 right-3">
            <a
              href={`https://www.google.com/maps/dir/?api=1&destination=${branchInfo.lat},${branchInfo.lng}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button className="w-full bg-blue-600 hover:bg-blue-700 h-10">
                <Navigation className="w-4 h-4 ml-2" />
                احصل على الاتجاهات
              </Button>
            </a>
          </div>
        </div>

        {/* Preparation Info */}
        {status === 'processing' && (
          <div className="bg-[#2a2a2a] rounded-xl p-4">
            <h5 className="text-white font-semibold text-sm mb-2">ماذا يحدث الآن؟</h5>
            <ul className="space-y-2 text-xs text-gray-400">
              <li className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5" />
                <span>التحقق من البيانات والمستندات</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5" />
                <span>طباعة الهوية الجديدة</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-gray-600 mt-1.5" />
                <span>الاختبارات النهائية والتغليف</span>
              </li>
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}