import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { motion } from 'framer-motion';
import { Truck, Phone, Navigation, Clock, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';

// Fix for default marker icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const deliveryIcon = L.divIcon({
  className: 'custom-delivery-icon',
  html: `
    <div style="
      background: linear-gradient(135deg, #b4ff00 0%, #8bc000 100%);
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 12px rgba(180, 255, 0, 0.4);
      border: 3px solid white;
    ">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="black" stroke-width="2">
        <rect x="1" y="3" width="15" height="13"></rect>
        <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
        <circle cx="5.5" cy="18.5" r="2.5"></circle>
        <circle cx="18.5" cy="18.5" r="2.5"></circle>
      </svg>
    </div>
  `,
  iconSize: [40, 40],
  iconAnchor: [20, 20],
});

const destinationIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

function MapController({ bounds }) {
  const map = useMap();
  useEffect(() => {
    if (bounds) {
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [bounds, map]);
  return null;
}

export default function DeliveryTracking({ deliveryAddress }) {
  // Simulated delivery person location (in real app, this would come from API)
  const [driverLocation, setDriverLocation] = useState({
    lat: 24.7180,
    lng: 46.6700,
    heading: 45
  });

  const destinationLocation = {
    lat: 24.7136,
    lng: 46.6753
  };

  // Simulate driver movement (in real app, this would be real-time updates)
  useEffect(() => {
    const interval = setInterval(() => {
      setDriverLocation(prev => ({
        lat: prev.lat + (Math.random() - 0.5) * 0.001,
        lng: prev.lng + (Math.random() - 0.5) * 0.001,
        heading: prev.heading + (Math.random() - 0.5) * 10
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const bounds = [
    [driverLocation.lat, driverLocation.lng],
    [destinationLocation.lat, destinationLocation.lng]
  ];

  const routeCoordinates = [
    [driverLocation.lat, driverLocation.lng],
    [destinationLocation.lat, destinationLocation.lng]
  ];

  const estimatedTime = '15-20 دقيقة';
  const distance = '2.3 كم';
  const driverName = 'أحمد محمد';
  const driverPhone = '+966 50 123 4567';

  return (
    <div className="bg-[#1a1a1a] rounded-3xl overflow-hidden border border-[#2a2a2a]">
      {/* Driver Info Card */}
      <div className="p-5 border-b border-[#2a2a2a]">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#b4ff00] to-[#8bc000] flex items-center justify-center">
            <Truck className="w-6 h-6 text-black" />
          </div>
          <div className="flex-1">
            <h3 className="text-white font-bold mb-0.5">المندوب في الطريق</h3>
            <p className="text-gray-400 text-sm">{driverName}</p>
          </div>
          <a href={`tel:${driverPhone}`}>
            <Button size="sm" className="bg-green-600 hover:bg-green-700 h-9">
              <Phone className="w-4 h-4 ml-1" />
              اتصال
            </Button>
          </a>
        </div>

        <div className="grid grid-cols-2 gap-3 mt-4">
          <div className="bg-[#2a2a2a] rounded-xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <Clock className="w-4 h-4 text-amber-400" />
              <span className="text-xs text-gray-400">الوصول المتوقع</span>
            </div>
            <p className="text-white font-semibold">{estimatedTime}</p>
          </div>
          <div className="bg-[#2a2a2a] rounded-xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <Navigation className="w-4 h-4 text-blue-400" />
              <span className="text-xs text-gray-400">المسافة المتبقية</span>
            </div>
            <p className="text-white font-semibold">{distance}</p>
          </div>
        </div>
      </div>

      {/* Map */}
      <div className="relative h-80">
        <MapContainer
          bounds={bounds}
          style={{ height: '100%', width: '100%' }}
          className="z-0"
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <MapController bounds={bounds} />

          {/* Route Line */}
          <Polyline
            positions={routeCoordinates}
            color="#b4ff00"
            weight={4}
            opacity={0.6}
            dashArray="10, 10"
          />

          {/* Driver Marker */}
          <Marker position={[driverLocation.lat, driverLocation.lng]} icon={deliveryIcon}>
            <Popup>
              <div className="p-2" dir="rtl">
                <p className="font-bold text-sm mb-1">{driverName}</p>
                <p className="text-xs text-gray-600">المندوب</p>
              </div>
            </Popup>
          </Marker>

          {/* Destination Marker */}
          <Marker position={[destinationLocation.lat, destinationLocation.lng]} icon={destinationIcon}>
            <Popup>
              <div className="p-2" dir="rtl">
                <p className="font-bold text-sm mb-1">موقع التسليم</p>
                <p className="text-xs text-gray-600">{deliveryAddress}</p>
              </div>
            </Popup>
          </Marker>
        </MapContainer>

        {/* Live Update Indicator */}
        <div className="absolute top-3 left-3 z-10">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-white/95 backdrop-blur-sm rounded-xl px-3 py-2 shadow-lg flex items-center gap-2"
          >
            <motion.div
              className="w-2 h-2 rounded-full bg-green-500"
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
            <span className="text-xs font-semibold text-gray-800">تتبع مباشر</span>
          </motion.div>
        </div>
      </div>

      {/* Delivery Address */}
      <div className="p-5 bg-[#0a0a0a] border-t border-[#2a2a2a]">
        <div className="flex items-start gap-3">
          <MapPin className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-xs text-gray-500 mb-1">عنوان التسليم</p>
            <p className="text-white text-sm">{deliveryAddress}</p>
          </div>
        </div>
      </div>
    </div>
  );
}