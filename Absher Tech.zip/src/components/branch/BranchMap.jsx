import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { Navigation, Clock, MapPin } from 'lucide-react';

// Fix for default marker icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const customIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const userIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

function MapController({ center }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, 13);
  }, [center, map]);
  return null;
}

export default function BranchMap({ branch, userLocation }) {
  const branchPosition = [branch.lat, branch.lng];
  const userPosition = userLocation ? [userLocation.lat, userLocation.lng] : null;
  const center = branchPosition;

  return (
    <div className="relative w-full h-64 rounded-2xl overflow-hidden border-2 border-[#2a2a2a]">
      <MapContainer
        center={center}
        zoom={13}
        style={{ height: '100%', width: '100%' }}
        className="z-0"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <MapController center={center} />
        
        {/* Branch Marker */}
        <Marker position={branchPosition} icon={customIcon}>
          <Popup>
            <div className="p-2" dir="rtl">
              <p className="font-bold text-sm mb-1">{branch.name}</p>
              <p className="text-xs text-gray-600 mb-2">{branch.address}</p>
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <Navigation className="w-3 h-3" />
                <span>{branch.distance}</span>
              </div>
            </div>
          </Popup>
        </Marker>

        {/* User Location Marker */}
        {userPosition && (
          <Marker position={userPosition} icon={userIcon}>
            <Popup>
              <div className="p-2" dir="rtl">
                <p className="font-bold text-sm">موقعك الحالي</p>
              </div>
            </Popup>
          </Marker>
        )}
      </MapContainer>

      {/* Travel Time Overlay */}
      <div className="absolute top-3 left-3 right-3 z-10 flex gap-2">
        <div className="flex-1 bg-white/95 backdrop-blur-sm rounded-xl px-3 py-2 shadow-lg">
          <div className="flex items-center gap-2 text-xs">
            <Navigation className="w-3.5 h-3.5 text-blue-600" />
            <span className="font-semibold text-gray-800">{branch.distance}</span>
            <span className="text-gray-500">•</span>
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            <span className="font-semibold text-gray-800">{branch.travelTime}</span>
          </div>
        </div>
      </div>

      {/* Directions Button */}
      <div className="absolute bottom-3 left-3 right-3 z-10">
        <a
          href={`https://www.google.com/maps/dir/?api=1&destination=${branch.lat},${branch.lng}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold px-4 py-2.5 rounded-xl shadow-lg transition-colors"
        >
          <Navigation className="w-4 h-4" />
          <span>احصل على الاتجاهات</span>
        </a>
      </div>
    </div>
  );
}