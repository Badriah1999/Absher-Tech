import React from 'react';
import { motion } from 'framer-motion';
import { Building2, Navigation, Clock, TrendingUp, Check, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function BranchList({ branches, selectedBranch, onSelectBranch, onClose }) {
  const getCrowdColor = (level) => {
    switch (level) {
      case 'منخفض': return 'text-green-500';
      case 'متوسط': return 'text-amber-500';
      case 'مرتفع': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  const getCrowdIcon = (level) => {
    switch (level) {
      case 'منخفض': return '●';
      case 'متوسط': return '●●';
      case 'مرتفع': return '●●●';
      default: return '●';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-end"
      onClick={onClose}
      dir="rtl"
    >
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: "spring", damping: 25, stiffness: 300 }}
        className="w-full max-w-md mx-auto bg-[#1a1a1a] rounded-t-3xl border-t-2 border-[#2a2a2a] max-h-[80vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-[#1a1a1a] border-b border-[#2a2a2a] px-6 py-4 z-10">
          <div className="flex items-center justify-between">
            <h3 className="text-white font-bold text-lg">اختر فرعاً آخر</h3>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-[#2a2a2a] hover:bg-[#3a3a3a] flex items-center justify-center transition-colors"
            >
              <span className="text-white">×</span>
            </button>
          </div>
          <p className="text-gray-400 text-sm mt-1">
            {branches.length} فروع متاحة
          </p>
        </div>

        {/* Branches List */}
        <div className="overflow-y-auto max-h-[calc(80vh-80px)] px-6 py-4">
          <div className="space-y-3">
            {branches.map((branch, index) => {
              const isSelected = selectedBranch?.id === branch.id;
              const isSuggested = index === 0;

              return (
                <motion.button
                  key={branch.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => onSelectBranch(branch)}
                  className={`w-full p-4 rounded-2xl border-2 transition-all text-right ${
                    isSelected
                      ? 'border-[#b4ff00] bg-[#b4ff00]/5'
                      : 'border-[#2a2a2a] bg-[#1a1a1a] hover:border-[#3a3a3a]'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 rounded-xl bg-[#2a2a2a] flex items-center justify-center flex-shrink-0">
                      <Building2 className="w-6 h-6 text-gray-400" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        {isSuggested && (
                          <Star className="w-4 h-4 text-[#b4ff00]" />
                        )}
                        <h4 className="font-semibold text-white text-sm">{branch.name}</h4>
                      </div>
                      <p className="text-xs text-gray-400 mb-2">{branch.address}</p>

                      <div className="flex items-center gap-3 text-xs">
                        <div className="flex items-center gap-1 text-gray-300">
                          <Navigation className="w-3 h-3" />
                          <span>{branch.distance}</span>
                        </div>
                        <div className="flex items-center gap-1 text-gray-300">
                          <Clock className="w-3 h-3" />
                          <span>{branch.travelTime}</span>
                        </div>
                        <div className={`flex items-center gap-1 ${getCrowdColor(branch.crowdLevel)}`}>
                          <TrendingUp className="w-3 h-3" />
                          <span>{getCrowdIcon(branch.crowdLevel)}</span>
                        </div>
                      </div>

                      {/* Working Hours */}
                      <div className="mt-2 pt-2 border-t border-[#2a2a2a]">
                        <div className="flex items-center gap-2 text-xs">
                          <Clock className="w-3 h-3 text-gray-500" />
                          <span className="text-gray-400">{branch.workingHours}</span>
                          {branch.isOpen && (
                            <span className="text-green-500 font-semibold">• مفتوح الآن</span>
                          )}
                        </div>
                      </div>
                    </div>

                    {isSelected && (
                      <div className="w-6 h-6 rounded-full bg-[#b4ff00] flex items-center justify-center flex-shrink-0">
                        <Check className="w-4 h-4 text-black" />
                      </div>
                    )}
                  </div>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-[#1a1a1a] border-t border-[#2a2a2a] px-6 py-4">
          <Button
            onClick={onClose}
            className="w-full h-12 bg-[#1a3d1a] hover:bg-[#234d23] text-white rounded-2xl"
          >
            تأكيد الاختيار
          </Button>
        </div>
      </motion.div>
    </motion.div>
  );
}