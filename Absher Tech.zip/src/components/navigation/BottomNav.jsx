import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { Home, FileText, Bell, User } from 'lucide-react';

export default function BottomNav() {
  const location = useLocation();
  
  const navItems = [
    { name: 'الرئيسية', icon: Home, path: createPageUrl('Notification') },
    { name: 'طلباتي', icon: FileText, path: createPageUrl('Requests') },
    { name: 'الإشعارات', icon: Bell, path: createPageUrl('Notifications') },
  ];

  const isActive = (path) => {
    return location.pathname === path;
  };

  return (
    <motion.div
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ type: "spring", stiffness: 260, damping: 20 }}
      className="fixed bottom-0 left-0 right-0 bg-[#1a1a1a] border-t border-[#2a2a2a] backdrop-blur-lg z-40"
      dir="rtl"
    >
      <div className="max-w-md mx-auto px-6 py-3">
        <div className="flex items-center justify-around">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.path);
            
            return (
              <Link key={item.name} to={item.path} className="flex-1">
                <motion.div
                  whileTap={{ scale: 0.95 }}
                  className={`flex flex-col items-center gap-1 py-2 px-4 rounded-2xl transition-colors ${
                    active ? 'bg-[#b4ff00]/10' : ''
                  }`}
                >
                  <div className="relative">
                    <Icon className={`w-6 h-6 ${active ? 'text-[#b4ff00]' : 'text-gray-500'}`} />
                    {active && (
                      <motion.div
                        layoutId="activeIndicator"
                        className="absolute -bottom-1 left-0 right-0 h-0.5 bg-[#b4ff00] rounded-full"
                      />
                    )}
                  </div>
                  <span className={`text-xs font-medium ${active ? 'text-[#b4ff00]' : 'text-gray-500'}`}>
                    {item.name}
                  </span>
                </motion.div>
              </Link>
            );
          })}
        </div>
      </div>
    </motion.div>
  );
}