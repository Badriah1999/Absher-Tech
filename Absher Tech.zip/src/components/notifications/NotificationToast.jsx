import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { X, CheckCircle, AlertCircle, Info, Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function NotificationToast() {
  const [user, setUser] = useState(null);
  const [dismissedIds, setDismissedIds] = useState(new Set());
  const [lastNotificationId, setLastNotificationId] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      const allNotifications = await base44.entities.Notification.filter(
        { user_email: user.email, is_read: false },
        '-created_date',
        5
      );
      return allNotifications;
    },
    enabled: !!user?.email,
    refetchInterval: 10000, // Check every 10 seconds
  });

  useEffect(() => {
    if (notifications.length > 0) {
      const latestNotification = notifications[0];
      if (latestNotification.id !== lastNotificationId) {
        setLastNotificationId(latestNotification.id);
      }
    }
  }, [notifications]);

  const activeNotification = notifications.find(n => 
    !dismissedIds.has(n.id) && n.id === lastNotificationId
  );

  const dismissNotification = (id) => {
    setDismissedIds(prev => new Set([...prev, id]));
    // Auto-mark as read after dismissing
    setTimeout(() => {
      base44.entities.Notification.update(id, { is_read: true });
    }, 500);
  };

  const getIcon = (type) => {
    switch (type) {
      case 'success': return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'warning': return <AlertCircle className="w-5 h-5 text-amber-500" />;
      case 'error': return <AlertCircle className="w-5 h-5 text-red-500" />;
      default: return <Info className="w-5 h-5 text-blue-500" />;
    }
  };

  const getBackground = (type) => {
    switch (type) {
      case 'success': return 'bg-green-50 border-green-200';
      case 'warning': return 'bg-amber-50 border-amber-200';
      case 'error': return 'bg-red-50 border-red-200';
      default: return 'bg-blue-50 border-blue-200';
    }
  };

  return (
    <AnimatePresence>
      {activeNotification && (
        <motion.div
          initial={{ opacity: 0, y: -100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -100 }}
          className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 w-[calc(100%-2rem)] max-w-md"
          dir="rtl"
        >
          <div className={`rounded-2xl border-2 shadow-xl ${getBackground(activeNotification.type)} p-4`}>
            <div className="flex gap-3">
              <div className="flex-shrink-0 mt-0.5">
                {getIcon(activeNotification.type)}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-bold text-slate-800 text-sm mb-1">
                  {activeNotification.title}
                </h4>
                <p className="text-slate-600 text-sm">
                  {activeNotification.message}
                </p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => dismissNotification(activeNotification.id)}
                className="flex-shrink-0 h-8 w-8 hover:bg-slate-200/50"
              >
                <X className="w-4 h-4 text-slate-500" />
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}