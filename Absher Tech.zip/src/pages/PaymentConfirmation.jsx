import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { 
  ChevronRight, Copy, Check, Info, CreditCard, 
  FileText, MapPin, Calendar
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import NotificationBell from '@/components/notifications/NotificationBell';
import { toast } from 'sonner';

export default function PaymentConfirmation() {
  const navigate = useNavigate();
  const [copied, setCopied] = useState(false);
  
  // Get parameters from URL
  const params = new URLSearchParams(window.location.search);
  const billNumber = params.get('bill');
  const referenceNumber = params.get('ref');
  const amount = params.get('amount') || '100';

  const handleCopy = () => {
    navigator.clipboard.writeText(billNumber);
    setCopied(true);
    toast.success('تم نسخ رقم الفاتورة');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-l from-[#1e3a5f] to-[#2d4a6f] text-white px-6 py-6">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl('Notification')}>
              <button className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
                <ChevronRight className="w-5 h-5" />
              </button>
            </Link>
            <div className="flex-1">
              <h1 className="text-xl font-bold">تأكيد الطلب</h1>
              <p className="text-white/70 text-sm">فاتورة الدفع</p>
            </div>
            <NotificationBell />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-md mx-auto px-6 py-6">
        {/* Success Message */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-emerald-50 border-2 border-emerald-200 rounded-3xl p-6 mb-6 text-center"
        >
          <div className="w-16 h-16 bg-[#059669] rounded-full flex items-center justify-center mx-auto mb-4">
            <Check className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">تم إنشاء الطلب بنجاح</h2>
          <p className="text-slate-600">رقم الطلب: <span className="font-mono font-semibold">{referenceNumber}</span></p>
        </motion.div>

        {/* SADAD Bill Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-3xl shadow-lg shadow-slate-200/50 p-6 mb-6"
        >
          <div className="flex items-center gap-3 mb-5">
            <div className="w-12 h-12 rounded-2xl bg-orange-50 flex items-center justify-center">
              <CreditCard className="w-6 h-6 text-orange-500" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800">فاتورة سداد</h3>
              <p className="text-sm text-slate-500">المبلغ: {amount} ريال</p>
            </div>
          </div>

          <div className="bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-300 rounded-2xl p-6 mb-4">
            <p className="text-slate-600 text-sm text-center mb-3">رقم الفاتورة</p>
            <div className="bg-white rounded-xl p-4 text-center">
              <p className="text-3xl font-bold text-slate-800 tracking-wider font-mono" dir="ltr">
                {billNumber}
              </p>
            </div>
            <Button
              onClick={handleCopy}
              variant="ghost"
              size="sm"
              className="w-full mt-3 h-9 text-orange-700 hover:text-orange-800 hover:bg-orange-200"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 ml-2" />
                  تم النسخ
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 ml-2" />
                  نسخ رقم الفاتورة
                </>
              )}
            </Button>
          </div>

          <div className="bg-blue-50 rounded-2xl p-4 border border-blue-200">
            <h4 className="font-semibold text-slate-800 mb-2 text-sm">كيفية الدفع:</h4>
            <ul className="space-y-2 text-xs text-slate-600">
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
                <span>توجه إلى أقرب جهاز صراف آلي أو استخدم تطبيق البنك</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
                <span>اختر خدمة "سداد" من القائمة</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
                <span>أدخل رقم الفاتورة المذكور أعلاه</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
                <span>أكمل عملية الدفع</span>
              </li>
            </ul>
          </div>
        </motion.div>

        {/* Important Notice */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-6"
        >
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-amber-800 font-medium mb-1">
                مهم: يجب إتمام الدفع خلال 72 ساعة
              </p>
              <p className="text-xs text-amber-700">
                بعد الدفع، سيتم معالجة طلبك خلال 1-2 يوم عمل
              </p>
            </div>
          </div>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-3"
        >
          <Link to={createPageUrl('RequestTracking') + `?ref=${referenceNumber}`}>
            <Button 
              className="w-full h-14 text-lg font-semibold bg-gradient-to-l from-[#1e3a5f] to-[#2d4a6f] hover:from-[#15314d] hover:to-[#1e3a5f] text-white rounded-2xl"
            >
              <FileText className="w-5 h-5 ml-2" />
              تتبع حالة الطلب
            </Button>
          </Link>
          
          <Link to={createPageUrl('Notification')}>
            <Button 
              variant="outline"
              className="w-full h-12 border-2 border-slate-200 hover:bg-slate-50 rounded-2xl"
            >
              العودة للرئيسية
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  );
}