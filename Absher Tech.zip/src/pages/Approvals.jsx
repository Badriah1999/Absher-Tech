import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ChevronRight, Camera, Upload, Check, MapPin, 
  CreditCard, Shield, Image as ImageIcon, User, Truck, Building2, Info, Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import NotificationBell from '@/components/notifications/NotificationBell';

export default function Approvals() {
  const navigate = useNavigate();
  const [photoOption, setPhotoOption] = useState('existing');
  const [uploadedPhoto, setUploadedPhoto] = useState(null);
  const [deliveryOption, setDeliveryOption] = useState('branch');
  const [address, setAddress] = useState({
    street: '',
    city: '',
    district: '',
    postalCode: ''
  });
  const [user, setUser] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const handleSubmit = async () => {
    if (isProcessing) return;
    
    setIsProcessing(true);
    
    try {
      // Generate SADAD bill number
      const sadadBillNumber = '1' + Math.floor(Math.random() * 10000000000).toString().padStart(10, '0');
      const referenceNumber = 'REF' + Date.now().toString().slice(-8);
      
      // Calculate amount
      const amount = deliveryOption === 'express' ? 150 : 100;
      
      // Create request
      const request = await base44.entities.Request.create({
        reference_number: referenceNumber,
        request_type: 'renewal',
        status: 'payment_pending',
        payment_method: 'sadad',
        payment_status: 'pending',
        amount: amount,
        delivery_method: deliveryOption,
        branch_name: deliveryOption === 'branch' ? 'فرع الرياض الرئيسي' : null,
        delivery_address: deliveryOption === 'express' ? address : null,
        sadad_bill_number: sadadBillNumber,
        user_email: user?.email || 'user@example.com'
      });
      
      // Create notification
      if (user?.email) {
        await base44.entities.Notification.create({
          title: 'تم إنشاء فاتورة سداد',
          message: `تم إنشاء فاتورة سداد برقم ${sadadBillNumber}. يرجى الدفع خلال 72 ساعة.`,
          type: 'success',
          category: 'payment',
          user_email: user.email,
          action_url: createPageUrl('RequestTracking') + `?ref=${referenceNumber}`
        });
      }
      
      // Navigate to payment page
      navigate(createPageUrl('PaymentConfirmation') + `?bill=${sadadBillNumber}&ref=${referenceNumber}&amount=${amount}`);
    } catch (error) {
      console.error('Error creating request:', error);
      setIsProcessing(false);
    }
  };

  const handlePhotoUpload = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedPhoto(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-l from-[#1e3a5f] to-[#2d4a6f] text-white px-6 py-6">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl('Notification')}>
              <button className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
                <ChevronRight className="w-5 h-5" />
              </button>
            </Link>
            <div className="flex-1">
              <h1 className="text-xl font-bold">تجديد الهوية</h1>
              <p className="text-white/70 text-sm">خيارات التجديد</p>
            </div>
            <NotificationBell />
          </div>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="max-w-md mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {[1, 2, 3, 4].map((step, index) => (
            <React.Fragment key={step}>
              <div className="flex flex-col items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold transition-all ${
                  step <= 2 ? 'bg-[#059669] text-white' : 'bg-slate-200 text-slate-400'
                }`}>
                  {step < 2 ? <Check className="w-4 h-4" /> : step}
                </div>
              </div>
              {index < 3 && (
                <div className={`flex-1 h-1 mx-2 rounded-full ${
                  step < 2 ? 'bg-[#059669]' : 'bg-slate-200'
                }`} />
              )}
            </React.Fragment>
          ))}
        </div>
        <div className="flex justify-between mt-2 px-1">
          <span className="text-xs text-slate-500">التنبيه</span>
          <span className="text-xs text-[#059669] font-medium">الخيارات</span>
          <span className="text-xs text-slate-400">المعالجة</span>
          <span className="text-xs text-slate-400">الإتمام</span>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-md mx-auto px-6 pb-40">
        {/* Photo Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl shadow-lg shadow-slate-100 p-6 mb-4"
        >
          <div className="flex items-center gap-3 mb-5">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center">
              <Camera className="w-6 h-6 text-blue-500" />
            </div>
            <div>
              <h2 className="font-bold text-slate-800">صورة الهوية</h2>
              <p className="text-sm text-slate-500">اختر مصدر الصورة</p>
            </div>
          </div>

          <RadioGroup value={photoOption} onValueChange={setPhotoOption} className="space-y-3">
            <Label
              htmlFor="existing"
              className={`flex items-center gap-4 p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                photoOption === 'existing' 
                  ? 'border-[#059669] bg-emerald-50/50' 
                  : 'border-slate-100 hover:border-slate-200'
              }`}
            >
              <RadioGroupItem value="existing" id="existing" className="text-[#059669]" />
              <div className="w-14 h-14 rounded-xl bg-slate-100 flex items-center justify-center overflow-hidden">
                <User className="w-8 h-8 text-slate-400" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-slate-700">استخدام الصورة الحالية</p>
                <p className="text-sm text-slate-500">صورة الهوية المسجلة</p>
              </div>
              {photoOption === 'existing' && (
                <div className="w-6 h-6 rounded-full bg-[#059669] flex items-center justify-center">
                  <Check className="w-4 h-4 text-white" />
                </div>
              )}
            </Label>

            <Label
              htmlFor="new"
              className={`flex items-center gap-4 p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                photoOption === 'new' 
                  ? 'border-[#059669] bg-emerald-50/50' 
                  : 'border-slate-100 hover:border-slate-200'
              }`}
            >
              <RadioGroupItem value="new" id="new" className="text-[#059669]" />
              <div className="w-14 h-14 rounded-xl bg-slate-100 flex items-center justify-center overflow-hidden">
                {uploadedPhoto ? (
                  <img src={uploadedPhoto} alt="Uploaded" className="w-full h-full object-cover" />
                ) : (
                  <Upload className="w-6 h-6 text-slate-400" />
                )}
              </div>
              <div className="flex-1">
                <p className="font-semibold text-slate-700">رفع صورة جديدة</p>
                <p className="text-sm text-slate-500">صورة شخصية حديثة</p>
              </div>
            </Label>
          </RadioGroup>

          <AnimatePresence>
            {photoOption === 'new' && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-4"
              >
                <label className="block">
                  <div className="border-2 border-dashed border-slate-200 rounded-2xl p-6 text-center cursor-pointer hover:border-[#059669] hover:bg-emerald-50/30 transition-all">
                    <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                    <p className="text-sm text-slate-600">اضغط لرفع الصورة</p>
                    <p className="text-xs text-slate-400 mt-1">PNG, JPG حتى 5MB</p>
                  </div>
                  <input 
                    type="file" 
                    accept="image/*" 
                    className="hidden" 
                    onChange={handlePhotoUpload}
                  />
                </label>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Delivery Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-3xl shadow-lg shadow-slate-100 p-6 mb-4"
        >
          <div className="flex items-center gap-3 mb-5">
            <div className="w-12 h-12 rounded-2xl bg-purple-50 flex items-center justify-center">
              <MapPin className="w-6 h-6 text-purple-500" />
            </div>
            <div>
              <h2 className="font-bold text-slate-800">طريقة الاستلام</h2>
              <p className="text-sm text-slate-500">كيف تريد استلام هويتك؟</p>
            </div>
          </div>

          <RadioGroup value={deliveryOption} onValueChange={setDeliveryOption} className="space-y-3">
            <Label
              htmlFor="branch"
              className={`flex items-center gap-4 p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                deliveryOption === 'branch' 
                  ? 'border-[#059669] bg-emerald-50/50' 
                  : 'border-slate-100 hover:border-slate-200'
              }`}
            >
              <RadioGroupItem value="branch" id="branch" className="text-[#059669]" />
              <div className="w-14 h-14 rounded-xl bg-slate-100 flex items-center justify-center">
                <Building2 className="w-7 h-7 text-slate-600" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-slate-700">الاستلام من أقرب فرع</p>
                <p className="text-sm text-slate-500">سيتم تحديد الفرع الأقرب لك</p>
                <p className="text-xs text-[#059669] font-medium mt-1">مجاناً</p>
              </div>
              {deliveryOption === 'branch' && (
                <div className="w-6 h-6 rounded-full bg-[#059669] flex items-center justify-center">
                  <Check className="w-4 h-4 text-white" />
                </div>
              )}
            </Label>

            <Label
              htmlFor="express"
              className={`flex items-center gap-4 p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                deliveryOption === 'express' 
                  ? 'border-[#059669] bg-emerald-50/50' 
                  : 'border-slate-100 hover:border-slate-200'
              }`}
            >
              <RadioGroupItem value="express" id="express" className="text-[#059669]" />
              <div className="w-14 h-14 rounded-xl bg-slate-100 flex items-center justify-center">
                <Truck className="w-7 h-7 text-slate-600" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-slate-700">التوصيل عبر البريد السريع</p>
                <p className="text-sm text-slate-500">توصيل لعنوانك خلال 3-5 أيام</p>
                <p className="text-xs text-amber-600 font-medium mt-1">+ 50 ريال</p>
              </div>
              {deliveryOption === 'express' && (
                <div className="w-6 h-6 rounded-full bg-[#059669] flex items-center justify-center">
                  <Check className="w-4 h-4 text-white" />
                </div>
              )}
            </Label>
          </RadioGroup>

          <AnimatePresence>
            {deliveryOption === 'express' && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-4 space-y-3"
              >
                <div className="pt-4 border-t border-slate-100">
                  <h3 className="font-semibold text-slate-700 mb-3 flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    عنوان التوصيل
                  </h3>
                  <div className="space-y-3">
                    <div>
                      <Label className="text-slate-600 text-sm mb-1.5 block">المدينة</Label>
                      <Input
                        placeholder="مثال: الرياض"
                        value={address.city}
                        onChange={(e) => setAddress({...address, city: e.target.value})}
                        className="h-11 rounded-xl"
                      />
                    </div>
                    <div>
                      <Label className="text-slate-600 text-sm mb-1.5 block">الحي</Label>
                      <Input
                        placeholder="مثال: العليا"
                        value={address.district}
                        onChange={(e) => setAddress({...address, district: e.target.value})}
                        className="h-11 rounded-xl"
                      />
                    </div>
                    <div>
                      <Label className="text-slate-600 text-sm mb-1.5 block">الشارع والعنوان التفصيلي</Label>
                      <Textarea
                        placeholder="مثال: شارع العليا العام، بجوار برج المملكة..."
                        value={address.street}
                        onChange={(e) => setAddress({...address, street: e.target.value})}
                        className="rounded-xl resize-none"
                        rows={3}
                      />
                    </div>
                    <div>
                      <Label className="text-slate-600 text-sm mb-1.5 block">الرمز البريدي</Label>
                      <Input
                        placeholder="مثال: 12345"
                        value={address.postalCode}
                        onChange={(e) => setAddress({...address, postalCode: e.target.value.replace(/\D/g, '').slice(0, 5)})}
                        className="h-11 rounded-xl"
                        maxLength={5}
                      />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Payment Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-3xl shadow-lg shadow-slate-100 p-6"
        >
          <div className="flex items-center gap-3 mb-5">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 flex items-center justify-center">
              <CreditCard className="w-6 h-6 text-amber-500" />
            </div>
            <div>
              <h2 className="font-bold text-slate-800">طريقة الدفع</h2>
              <p className="text-sm text-slate-500">اختر وسيلة الدفع المناسبة</p>
            </div>
          </div>

          <div className="bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-[#059669] rounded-2xl p-5">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-orange-200 to-orange-100 flex items-center justify-center">
                <div className="text-orange-600 font-bold text-lg">سداد</div>
              </div>
              <div className="flex-1">
                <p className="font-bold text-slate-800 text-lg">سداد</p>
                <p className="text-sm text-slate-600">الدفع عبر أجهزة الصراف الآلي</p>
              </div>
              <div className="w-8 h-8 rounded-full bg-[#059669] flex items-center justify-center">
                <Check className="w-5 h-5 text-white" />
              </div>
            </div>
            
            <div className="p-4 bg-white rounded-xl border border-orange-200">
              <div className="flex items-start gap-3">
                <Info className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm text-slate-700 font-medium mb-1">
                    رقم الفاتورة سيظهر بعد تأكيد الطلب
                  </p>
                  <p className="text-xs text-slate-600">
                    يمكنك الدفع خلال 72 ساعة من خلال أجهزة الصراف الآلي أو تطبيق البنك
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 p-4 bg-slate-50 rounded-2xl space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-slate-600">رسوم التجديد</span>
              <span className="font-semibold text-slate-800">100 ريال</span>
            </div>
            {deliveryOption === 'express' && (
              <div className="flex justify-between items-center">
                <span className="text-slate-600">رسوم التوصيل</span>
                <span className="font-semibold text-amber-600">50 ريال</span>
              </div>
            )}
            <div className="pt-2 border-t border-slate-200 flex justify-between items-center">
              <span className="text-slate-700 font-semibold">المجموع</span>
              <span className="text-xl font-bold text-slate-800">
                {deliveryOption === 'express' ? '150' : '100'} ريال
              </span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Fixed Bottom Button */}
      <div className="fixed bottom-20 left-0 right-0 bg-white border-t border-slate-200 p-5 shadow-2xl z-50">
        <div className="max-w-md mx-auto">
          <Button 
            onClick={handleSubmit}
            disabled={isProcessing}
            className="w-full h-16 text-lg font-bold bg-gradient-to-l from-[#059669] to-[#10b981] hover:from-[#047857] hover:to-[#059669] rounded-2xl shadow-lg shadow-emerald-500/25 transition-all duration-300 disabled:opacity-50"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-5 h-5 ml-2 animate-spin" />
                جاري المعالجة...
              </>
            ) : (
              <>
                <Shield className="w-5 h-5 ml-2" />
                متابعة وتأكيد الطلب
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}