import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { 
  ChevronRight, Shield, AlertCircle, Calendar, Clock, 
  CheckCircle, XCircle, Sparkles, Bot
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import NotificationBell from '@/components/notifications/NotificationBell';

export default function AutoRenewConfirmation() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const documentType = 'الهوية الوطنية';
  const expiryDate = '1446/06/15';
  const daysRemaining = 10;

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const handleConfirm = async () => {
    if (user?.email) {
      await base44.entities.Notification.create({
        title: 'تم تأكيد التجديد التلقائي',
        message: 'بدأنا بإجراءات تجديد هويتك الوطنية تلقائياً',
        type: 'success',
        category: 'renewal',
        user_email: user.email,
        action_url: createPageUrl('PhotoSelection')
      });
    }
    navigate(createPageUrl('PhotoSelection'));
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a]" dir="rtl">
      {/* Header */}
      <div className="bg-[#0a0a0a] text-white px-6 py-6">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl('Notification')}>
              <button className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
                <ChevronRight className="w-5 h-5" />
              </button>
            </Link>
            <div className="flex-1">
              <h1 className="text-xl font-bold">تأكيد بدء التجديد التلقائي</h1>
              <p className="text-white/70 text-sm">عبر أبشر-بوت</p>
            </div>
            <NotificationBell />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-md mx-auto px-6 py-6">
        {/* Bot Icon */}
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ 
            type: "spring",
            stiffness: 260,
            damping: 15,
            duration: 0.6
          }}
          className="flex justify-center mb-6"
        >
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-[#b4ff00]/20 to-[#059669]/20 flex items-center justify-center border-2 border-[#b4ff00]/30">
            <Bot className="w-12 h-12 text-[#b4ff00]" />
          </div>
        </motion.div>

        {/* Document Info Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#1a1a1a] rounded-3xl border border-[#2a2a2a] p-6 mb-6"
        >
          <h3 className="text-white font-bold mb-4 flex items-center gap-2">
            <Shield className="w-5 h-5 text-[#b4ff00]" />
            معلومات الوثيقة
          </h3>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between py-2 border-b border-[#2a2a2a]">
              <span className="text-gray-400 text-sm">نوع الوثيقة</span>
              <span className="text-white font-semibold">{documentType}</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-[#2a2a2a]">
              <span className="text-gray-400 text-sm">تاريخ الانتهاء</span>
              <span className="text-white font-semibold">{expiryDate} هـ</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-gray-400 text-sm">الأيام المتبقية</span>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-500" />
                <span className="text-amber-500 font-bold">{daysRemaining} يوم</span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Bot Actions Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-[#1a1a1a] rounded-3xl border border-[#2a2a2a] p-6 mb-6"
        >
          <h3 className="text-white font-bold mb-4 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#b4ff00]" />
            ماذا سيفعل أبشر-بوت؟
          </h3>
          
          <div className="space-y-3">
            {[
              'رفع الصورة (إن لزم)',
              'تقديم طلب التجديد',
              'اختيار أقرب فرع مناسب عبر الذكاء الاصطناعي',
              'متابعة حالة الطلب وإشعارك أولاً بأول'
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
                className="flex items-start gap-3"
              >
                <div className="w-6 h-6 rounded-full bg-[#b4ff00]/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <CheckCircle className="w-4 h-4 text-[#b4ff00]" />
                </div>
                <span className="text-gray-300 text-sm">{item}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Question */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="text-center mb-6"
        >
          <p className="text-white font-semibold text-lg mb-2">
            هل ترغب بالبدء في إجراءات التجديد التلقائي؟
          </p>
          <p className="text-gray-400 text-sm">
            سيتم توجيهك لاختيار الصورة ثم إكمال باقي الإجراءات
          </p>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="space-y-3"
        >
          <Button
            onClick={handleConfirm}
            className="w-full h-14 text-lg font-semibold bg-[#1a3d1a] hover:bg-[#234d23] text-white rounded-2xl"
          >
            <CheckCircle className="w-5 h-5 ml-2" />
            نعم، أوافق على البدء
          </Button>
          
          <Link to={createPageUrl('Notification')}>
            <Button
              variant="outline"
              className="w-full h-14 text-lg font-semibold border-[#2a2a2a] bg-transparent text-white hover:bg-[#1a1a1a] rounded-2xl"
            >
              <XCircle className="w-5 h-5 ml-2" />
              إلغاء
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  );
}