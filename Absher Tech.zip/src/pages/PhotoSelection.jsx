import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { 
  ChevronRight, Camera, Check, User, Upload
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import NotificationBell from '@/components/notifications/NotificationBell';

export default function PhotoSelection() {
  const navigate = useNavigate();
  const [photoOption, setPhotoOption] = useState('existing');

  const handleContinue = () => {
    if (photoOption === 'existing') {
      navigate(createPageUrl('PaymentSadad'));
    } else {
      navigate(createPageUrl('PhotoUpload'));
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a]" dir="rtl">
      {/* Header */}
      <div className="bg-[#0a0a0a] text-white px-6 py-6">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl('AutoRenewConfirmation')}>
              <button className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
                <ChevronRight className="w-5 h-5" />
              </button>
            </Link>
            <div className="flex-1">
              <h1 className="text-xl font-bold">اختيار صورة التجديد</h1>
              <p className="text-white/70 text-sm">اختر الصورة المناسبة</p>
            </div>
            <NotificationBell />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-md mx-auto px-6 py-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#1a1a1a] rounded-3xl border border-[#2a2a2a] p-6 mb-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-blue-500/10 flex items-center justify-center">
              <Camera className="w-6 h-6 text-blue-400" />
            </div>
            <div>
              <h2 className="font-bold text-white">اختر مصدر الصورة</h2>
              <p className="text-sm text-gray-400">صورة شخصية للهوية</p>
            </div>
          </div>

          <RadioGroup value={photoOption} onValueChange={setPhotoOption} className="space-y-4">
            {/* Existing Photo Option */}
            <Label
              htmlFor="existing"
              className={`flex items-start gap-4 p-5 rounded-2xl border-2 cursor-pointer transition-all ${
                photoOption === 'existing' 
                  ? 'border-[#b4ff00] bg-[#b4ff00]/5' 
                  : 'border-[#2a2a2a] hover:border-[#3a3a3a]'
              }`}
            >
              <RadioGroupItem value="existing" id="existing" className="mt-1" />
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-16 h-20 rounded-xl bg-[#2a2a2a] flex items-center justify-center overflow-hidden border border-[#3a3a3a]">
                    <User className="w-10 h-10 text-gray-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-white mb-1">استخدام الصورة الحالية</p>
                    <p className="text-sm text-gray-400">الصورة المسجلة في النظام</p>
                  </div>
                  {photoOption === 'existing' && (
                    <div className="w-6 h-6 rounded-full bg-[#b4ff00] flex items-center justify-center">
                      <Check className="w-4 h-4 text-black" />
                    </div>
                  )}
                </div>
                <div className="bg-[#2a2a2a] rounded-xl p-3 border border-[#3a3a3a]">
                  <p className="text-xs text-gray-400">
                    سيتم استخدام صورتك الحالية دون رفع صورة جديدة
                  </p>
                </div>
              </div>
            </Label>

            {/* New Photo Option */}
            <Label
              htmlFor="new"
              className={`flex items-start gap-4 p-5 rounded-2xl border-2 cursor-pointer transition-all ${
                photoOption === 'new' 
                  ? 'border-[#b4ff00] bg-[#b4ff00]/5' 
                  : 'border-[#2a2a2a] hover:border-[#3a3a3a]'
              }`}
            >
              <RadioGroupItem value="new" id="new" className="mt-1" />
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-16 h-20 rounded-xl bg-[#2a2a2a] flex items-center justify-center border border-[#3a3a3a]">
                    <Upload className="w-8 h-8 text-gray-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-white mb-1">رفع صورة جديدة</p>
                    <p className="text-sm text-gray-400">صورة شخصية حديثة (4×6)</p>
                  </div>
                  {photoOption === 'new' && (
                    <div className="w-6 h-6 rounded-full bg-[#b4ff00] flex items-center justify-center">
                      <Check className="w-4 h-4 text-black" />
                    </div>
                  )}
                </div>
                <div className="bg-amber-500/10 rounded-xl p-3 border border-amber-500/20">
                  <p className="text-xs text-amber-400">
                    <span className="font-semibold">متطلبات الصورة:</span> خلفية بيضاء، مقاس 4×6، وجه واضح
                  </p>
                </div>
              </div>
            </Label>
          </RadioGroup>
        </motion.div>

        {/* Continue Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Button
            onClick={handleContinue}
            className="w-full h-14 text-lg font-semibold bg-[#1a3d1a] hover:bg-[#234d23] text-white rounded-2xl"
          >
            {photoOption === 'existing' ? 'متابعة للدفع' : 'رفع الصورة'}
          </Button>
        </motion.div>
      </div>
    </div>
  );
}