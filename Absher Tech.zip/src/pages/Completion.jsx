import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { 
  PartyPopper, Check, CreditCard, MapPin, Calendar,
  Download, Share2, ChevronLeft, Shield, QrCode, User
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import NotificationBell from '@/components/notifications/NotificationBell';
import html2canvas from 'html2canvas';

export default function Completion() {
  const [showDigitalId, setShowDigitalId] = useState(false);
  const [user, setUser] = useState(null);
  const receiptRef = useRef(null);
  
  const params = new URLSearchParams(window.location.search);
  const paymentMethod = params.get('payment');
  const sadadBillNumber = params.get('bill');

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  useEffect(() => {
    // Send completion notification
    const sendCompletionNotification = async () => {
      if (user?.email) {
        const message = paymentMethod === 'sadad'
          ? `تم إنشاء طلب التجديد بنجاح. يرجى إتمام الدفع عبر سداد برقم الفاتورة ${sadadBillNumber}.`
          : 'تهانينا! تم إكمال طلب تجديد هويتك الوطنية. يمكنك الآن استخدام الهوية الرقمية.';
          
        await base44.entities.Notification.create({
          title: paymentMethod === 'sadad' ? 'في انتظار الدفع' : 'تم تجديد الهوية بنجاح! 🎉',
          message: message,
          type: paymentMethod === 'sadad' ? 'warning' : 'success',
          category: 'renewal',
          user_email: user.email,
          action_url: window.location.pathname
        });
      }
    };
    
    if (user) {
      sendCompletionNotification();
    }
  }, [user, paymentMethod, sadadBillNumber]);

  const transactionDetails = {
    referenceNumber: 'ID-2024-789456',
    date: '1446/06/05',
    amount: '100 ريال',
    branch: 'فرع الرياض - العليا',
    estimatedDate: '1446/06/10',
  };

  const handleDownloadReceipt = async () => {
    if (!receiptRef.current) return;
    
    try {
      const canvas = await html2canvas(receiptRef.current, {
        backgroundColor: '#ffffff',
        scale: 2,
        logging: false,
      });
      
      const link = document.createElement('a');
      link.download = `إيصال-تجديد-الهوية-${transactionDetails.referenceNumber}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch (error) {
      console.error('Error downloading receipt:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 to-white" dir="rtl">
      {/* Success Header */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-l from-[#059669] to-[#10b981]" />
        <div className="absolute inset-0">
          <div className="absolute top-10 right-10 w-32 h-32 bg-white/10 rounded-full blur-2xl" />
          <div className="absolute bottom-10 left-10 w-40 h-40 bg-white/10 rounded-full blur-2xl" />
        </div>
        
        <div className="relative px-6 py-12 text-white text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", duration: 0.6 }}
            className="w-24 h-24 bg-white rounded-full mx-auto mb-6 flex items-center justify-center shadow-2xl"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.3, type: "spring" }}
            >
              <PartyPopper className="w-12 h-12 text-[#059669]" />
            </motion.div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <h1 className="text-3xl font-bold mb-2">
              {paymentMethod === 'sadad' ? 'تم إنشاء الطلب!' : 'تم بنجاح! 🎉'}
            </h1>
            <p className="text-white/90 text-lg">
              {paymentMethod === 'sadad' 
                ? 'في انتظار إتمام الدفع عبر سداد'
                : 'تم تجديد هويتك الوطنية'}
            </p>
          </motion.div>
        </div>
      </div>

      {/* Progress Complete */}
      <div className="max-w-md mx-auto px-6 -mt-4">
        <motion.div
          ref={receiptRef}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white rounded-3xl shadow-xl shadow-slate-200/50 overflow-hidden"
        >
          {/* Steps Complete */}
          <div className="p-6 border-b border-slate-100">
            <div className="flex items-center justify-between">
              {[1, 2, 3, 4].map((step, index) => (
                <React.Fragment key={step}>
                  <div className="flex flex-col items-center">
                    <div className="w-8 h-8 rounded-full bg-[#059669] text-white flex items-center justify-center">
                      <Check className="w-4 h-4" />
                    </div>
                  </div>
                  {index < 3 && (
                    <div className="flex-1 h-1 mx-2 rounded-full bg-[#059669]" />
                  )}
                </React.Fragment>
              ))}
            </div>
            <p className="text-center text-[#059669] font-medium mt-3">جميع الخطوات مكتملة</p>
          </div>

          {/* Transaction Details */}
          <div className="p-6 space-y-4">
            <h3 className="font-bold text-slate-800 mb-4">تفاصيل العملية</h3>
            
            {paymentMethod === 'sadad' && sadadBillNumber && (
              <div className="bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-300 rounded-2xl p-5 mb-4">
                <p className="text-slate-600 text-sm text-center mb-2 font-semibold">رقم فاتورة سداد</p>
                <div className="bg-white rounded-xl p-3 text-center mb-3">
                  <p className="text-2xl font-bold text-slate-800 tracking-wider font-mono" dir="ltr">
                    {sadadBillNumber}
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigator.clipboard.writeText(sadadBillNumber)}
                  className="w-full h-9 text-orange-700 border-orange-300 hover:bg-orange-200"
                >
                  نسخ رقم الفاتورة
                </Button>
                <p className="text-xs text-orange-700 text-center mt-3">
                  يرجى الدفع خلال 72 ساعة عبر أجهزة الصراف الآلي
                </p>
              </div>
            )}
            
            <div className="space-y-3">
              <div className="flex items-center justify-between py-3 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
                    <Shield className="w-5 h-5 text-blue-500" />
                  </div>
                  <span className="text-slate-600">رقم المرجع</span>
                </div>
                <span className="font-semibold text-slate-800 font-mono">{transactionDetails.referenceNumber}</span>
              </div>
              
              <div className="flex items-center justify-between py-3 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-50 flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-purple-500" />
                  </div>
                  <span className="text-slate-600">تاريخ العملية</span>
                </div>
                <span className="font-semibold text-slate-800">{transactionDetails.date}</span>
              </div>
              
              <div className="flex items-center justify-between py-3 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    paymentMethod === 'sadad' ? 'bg-orange-50' : 'bg-green-50'
                  }`}>
                    <CreditCard className={`w-5 h-5 ${
                      paymentMethod === 'sadad' ? 'text-orange-500' : 'text-green-500'
                    }`} />
                  </div>
                  <span className="text-slate-600">
                    {paymentMethod === 'sadad' ? 'المبلغ المطلوب' : 'المبلغ المدفوع'}
                  </span>
                </div>
                <span className={`font-semibold ${
                  paymentMethod === 'sadad' ? 'text-orange-600' : 'text-[#059669]'
                }`}>
                  {transactionDetails.amount}
                </span>
              </div>
              
              <div className="flex items-center justify-between py-3 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center">
                    <MapPin className="w-5 h-5 text-amber-500" />
                  </div>
                  <span className="text-slate-600">فرع الاستلام</span>
                </div>
                <span className="font-semibold text-slate-800 text-sm">{transactionDetails.branch}</span>
              </div>
              
              <div className="flex items-center justify-between py-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-indigo-500" />
                  </div>
                  <span className="text-slate-600">موعد الاستلام</span>
                </div>
                <span className="font-semibold text-slate-800">{transactionDetails.estimatedDate}</span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="mt-6 space-y-3"
        >
          <Button 
            onClick={() => setShowDigitalId(true)}
            className="w-full h-14 text-lg font-semibold bg-gradient-to-l from-[#1e3a5f] to-[#2d4a6f] hover:from-[#162d4a] hover:to-[#1e3a5f] rounded-2xl shadow-lg shadow-slate-400/25 transition-all duration-300"
          >
            <QrCode className="w-5 h-5 ml-2" />
            عرض الهوية الرقمية
          </Button>
          
          <div className="grid grid-cols-2 gap-3">
            <Button 
              onClick={handleDownloadReceipt}
              variant="outline"
              className="h-12 rounded-xl border-2 border-slate-200 hover:border-slate-300 hover:bg-slate-50"
            >
              <Download className="w-4 h-4 ml-2" />
              تحميل الإيصال
            </Button>
            <Button 
              variant="outline"
              className="h-12 rounded-xl border-2 border-slate-200 hover:border-slate-300 hover:bg-slate-50"
            >
              <Share2 className="w-4 h-4 ml-2" />
              مشاركة
            </Button>
          </div>
        </motion.div>

        {/* Next Steps */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9 }}
          className={`mt-6 mb-8 rounded-2xl p-4 border ${
            paymentMethod === 'sadad' 
              ? 'bg-orange-50 border-orange-200'
              : 'bg-blue-50 border-blue-100'
          }`}
        >
          <h4 className="font-semibold text-slate-700 mb-2">الخطوات القادمة</h4>
          <ul className="text-sm text-slate-600 space-y-2">
            {paymentMethod === 'sadad' ? (
              <>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                  <span>قم بالدفع عبر أجهزة الصراف الآلي باستخدام رقم الفاتورة</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                  <span>أكمل الدفع خلال 72 ساعة لتفادي إلغاء الطلب</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                  <span>ستصلك رسالة تأكيد بعد استلام الدفع</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                  <span>بعد الدفع، ستصلك رسالة عند جاهزية الهوية</span>
                </li>
              </>
            ) : (
              <>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-[#059669] mt-0.5 flex-shrink-0" />
                  <span>ستصلك رسالة نصية عند جاهزية الهوية للاستلام</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-[#059669] mt-0.5 flex-shrink-0" />
                  <span>توجه للفرع المحدد مع إثبات هوية ساري</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-[#059669] mt-0.5 flex-shrink-0" />
                  <span>يمكنك استخدام الهوية الرقمية حتى استلام البطاقة</span>
                </li>
              </>
            )}
          </ul>
        </motion.div>
      </div>

      {/* Digital ID Dialog */}
      <Dialog open={showDigitalId} onOpenChange={setShowDigitalId}>
        <DialogContent className="sm:max-w-md mx-4 rounded-3xl p-0 overflow-hidden" dir="rtl">
          <div className="bg-gradient-to-l from-[#1e3a5f] to-[#2d4a6f] p-6">
            <DialogHeader>
              <DialogTitle className="text-xl font-bold text-white flex items-center gap-3">
                <Shield className="w-5 h-5" />
                الهوية الوطنية الرقمية
              </DialogTitle>
            </DialogHeader>
          </div>
          
          <div className="p-6">
            {/* Digital ID Card */}
            <div className="bg-gradient-to-br from-[#1e3a5f] via-[#2d4a6f] to-[#3d5a7f] rounded-2xl p-6 text-white relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-full">
                <div className="absolute top-4 left-4 w-20 h-20 bg-white/5 rounded-full blur-xl" />
                <div className="absolute bottom-4 right-4 w-32 h-32 bg-white/5 rounded-full blur-xl" />
              </div>
              
              <div className="relative">
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <p className="text-white/60 text-xs mb-1">المملكة العربية السعودية</p>
                    <p className="font-bold text-lg">الهوية الوطنية</p>
                  </div>
                  <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                    <Shield className="w-6 h-6" />
                  </div>
                </div>
                
                <div className="flex gap-4 mb-6">
                  <div className="w-20 h-24 bg-white/20 rounded-xl flex items-center justify-center">
                    <User className="w-10 h-10 text-white/60" />
                  </div>
                  <div className="flex-1">
                    <p className="text-white/60 text-xs mb-1">الاسم</p>
                    <p className="font-bold mb-3">محمد عبدالله الأحمد</p>
                    <p className="text-white/60 text-xs mb-1">رقم الهوية</p>
                    <p className="font-mono font-bold tracking-wider">1098765432</p>
                  </div>
                </div>
                
                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-white/60 text-xs mb-1">تاريخ الانتهاء</p>
                    <p className="font-semibold">1456/06/15</p>
                  </div>
                  <div className="w-16 h-16 bg-white rounded-xl p-2">
                    <div className="w-full h-full bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMSAyMSI+PHBhdGggZmlsbD0iIzFlM2E1ZiIgZD0iTTAgMGg3djdIMHptMTQgMGg3djdoLTd6TTAgMTRoN3Y3SDB6bTggOGgxdi0xSDh2MXptMC0yaDFWOUg4djExem0yIDB2MWNIM3YtMWg3em0wLTJINHYxaDZ2LTF6bTAtMkg0djFoNnYtMXptMC0ySDV2MWg1di0xem0wLTJINnYxaDR2LTF6bTAtMkg3djFoM3YtMXoiLz48L3N2Zz4=')] bg-contain bg-center bg-no-repeat" />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-6 flex items-center justify-center gap-2 text-sm text-slate-500">
              <Check className="w-4 h-4 text-[#059669]" />
              <span>هوية رقمية موثقة وسارية المفعول</span>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}