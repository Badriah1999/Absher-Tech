import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { 
  ChevronRight, Camera, Image as ImageIcon, Upload, Check, 
  RefreshCw, AlertCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import NotificationBell from '@/components/notifications/NotificationBell';

export default function PhotoUpload() {
  const navigate = useNavigate();
  const [uploadedPhoto, setUploadedPhoto] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [confirmed, setConfirmed] = useState(false);

  const handlePhotoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploading(true);
      try {
        // Upload to server
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        setUploadedPhoto(file_url);
      } catch (error) {
        console.error('Upload error:', error);
      } finally {
        setUploading(false);
      }
    }
  };

  const handleConfirm = () => {
    if (uploadedPhoto && confirmed) {
      navigate(createPageUrl('PaymentSadad'));
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a]" dir="rtl">
      {/* Header */}
      <div className="bg-[#0a0a0a] text-white px-6 py-6">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl('PhotoSelection')}>
              <button className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
                <ChevronRight className="w-5 h-5" />
              </button>
            </Link>
            <div className="flex-1">
              <h1 className="text-xl font-bold">رفع صورة جديدة (4×6)</h1>
              <p className="text-white/70 text-sm">صورة شخصية للهوية</p>
            </div>
            <NotificationBell />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-md mx-auto px-6 py-6">
        {/* Requirements Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-blue-500/10 border border-blue-500/20 rounded-3xl p-5 mb-6"
        >
          <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-blue-400" />
            متطلبات الصورة
          </h3>
          <ul className="space-y-2">
            {[
              'خلفية بيضاء',
              'مقاس 4×6',
              'وجه واضح بالكامل',
              'بدون نظارات شمسية',
              'صيغة: JPG / PNG'
            ].map((item, index) => (
              <li key={index} className="flex items-center gap-2 text-sm text-gray-300">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-400"></div>
                {item}
              </li>
            ))}
          </ul>
        </motion.div>

        {/* Upload Area */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-[#1a1a1a] rounded-3xl border border-[#2a2a2a] p-6 mb-6"
        >
          {!uploadedPhoto ? (
            <div className="space-y-4">
              <label className="block">
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={handlePhotoUpload}
                  disabled={uploading}
                />
                <div className="border-2 border-dashed border-[#2a2a2a] rounded-2xl p-8 text-center cursor-pointer hover:border-[#b4ff00]/30 hover:bg-[#b4ff00]/5 transition-all">
                  <Camera className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                  <p className="text-white font-semibold mb-1">التقاط بالكاميرا</p>
                  <p className="text-sm text-gray-400">اضغط للتصوير مباشرة</p>
                </div>
              </label>

              <label className="block">
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handlePhotoUpload}
                  disabled={uploading}
                />
                <div className="border-2 border-dashed border-[#2a2a2a] rounded-2xl p-8 text-center cursor-pointer hover:border-[#b4ff00]/30 hover:bg-[#b4ff00]/5 transition-all">
                  <ImageIcon className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                  <p className="text-white font-semibold mb-1">اختيار من الاستوديو</p>
                  <p className="text-sm text-gray-400">اختر صورة من معرض الصور</p>
                </div>
              </label>

              {uploading && (
                <div className="text-center py-4">
                  <Upload className="w-8 h-8 text-[#b4ff00] mx-auto mb-2 animate-pulse" />
                  <p className="text-gray-400 text-sm">جاري الرفع...</p>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {/* Preview */}
              <div className="relative">
                <img
                  src={uploadedPhoto}
                  alt="Uploaded"
                  className="w-full rounded-2xl border-2 border-[#b4ff00]"
                />
                <div className="absolute top-3 right-3">
                  <div className="bg-[#b4ff00] rounded-full p-2">
                    <Check className="w-4 h-4 text-black" />
                  </div>
                </div>
              </div>

              {/* Re-upload Button */}
              <label>
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handlePhotoUpload}
                />
                <Button
                  type="button"
                  variant="outline"
                  className="w-full h-12 border-[#2a2a2a] bg-transparent text-white hover:bg-[#1a1a1a] rounded-2xl"
                >
                  <RefreshCw className="w-4 h-4 ml-2" />
                  إعادة الرفع
                </Button>
              </label>

              {/* Confirmation Checkbox */}
              <div className="flex items-start gap-3 p-4 bg-[#2a2a2a] rounded-2xl">
                <Checkbox
                  id="confirm"
                  checked={confirmed}
                  onCheckedChange={setConfirmed}
                  className="mt-0.5"
                />
                <Label htmlFor="confirm" className="text-sm text-gray-300 cursor-pointer flex-1">
                  أقر أن الصورة مطابقة للمواصفات المطلوبة (خلفية بيضاء، مقاس 4×6، وجه واضح)
                </Label>
              </div>
            </div>
          )}
        </motion.div>

        {/* Continue Button */}
        {uploadedPhoto && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Button
              onClick={handleConfirm}
              disabled={!confirmed}
              className="w-full h-14 text-lg font-semibold bg-[#1a3d1a] hover:bg-[#234d23] text-white rounded-2xl disabled:opacity-50 disabled:cursor-not-allowed"
            >
              تأكيد الصورة ومتابعة
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
}