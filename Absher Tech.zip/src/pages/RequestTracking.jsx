import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { ChevronRight, Package, Calendar, CreditCard, MapPin, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import NotificationBell from '@/components/notifications/NotificationBell';
import OrderStatusTimeline from '@/components/tracking/OrderStatusTimeline';
import DeliveryTracking from '@/components/tracking/DeliveryTracking';
import BranchStatus from '@/components/tracking/BranchStatus';

export default function RequestTracking() {
  const navigate = useNavigate();
  const [request, setRequest] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Get reference number from URL
  const params = new URLSearchParams(window.location.search);
  const refNumber = params.get('ref');

  const fetchRequest = async () => {
    try {
      const requests = await base44.entities.Request.filter(
        { reference_number: refNumber },
        '-created_date',
        1
      );
      if (requests.length > 0) {
        setRequest(requests[0]);
      }
    } catch (error) {
      console.error('Error fetching request:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    if (refNumber) {
      fetchRequest();
    }
  }, [refNumber]);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchRequest();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-white">جاري التحميل...</div>
      </div>
    );
  }

  if (!request) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-white">لم يتم العثور على الطلب</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a]" dir="rtl">
      {/* Header */}
      <div className="bg-[#0a0a0a] text-white px-6 py-6 border-b border-[#2a2a2a]">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl('Requests')}>
              <button className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
                <ChevronRight className="w-5 h-5" />
              </button>
            </Link>
            <div className="flex-1">
              <h1 className="text-xl font-bold">تتبع الطلب</h1>
              <p className="text-white/70 text-sm">{request.reference_number}</p>
            </div>
            <button
              onClick={handleRefresh}
              disabled={refreshing}
              className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
            >
              <RefreshCw className={`w-5 h-5 ${refreshing ? 'animate-spin' : ''}`} />
            </button>
            <NotificationBell />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-md mx-auto px-6 py-6 space-y-4">
        {/* Request Summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#1a1a1a] rounded-3xl p-5 border border-[#2a2a2a]"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-[#b4ff00]/10 flex items-center justify-center">
              <Package className="w-6 h-6 text-[#b4ff00]" />
            </div>
            <div>
              <h3 className="text-white font-bold">تجديد الهوية الوطنية</h3>
              <p className="text-gray-400 text-sm">رقم المرجع: {request.reference_number}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#2a2a2a] rounded-xl p-3">
              <div className="flex items-center gap-2 mb-1">
                <Calendar className="w-4 h-4 text-blue-400" />
                <span className="text-xs text-gray-400">تاريخ الطلب</span>
              </div>
              <p className="text-white text-sm font-semibold">
                {new Date(request.created_date).toLocaleDateString('ar-SA')}
              </p>
            </div>
            <div className="bg-[#2a2a2a] rounded-xl p-3">
              <div className="flex items-center gap-2 mb-1">
                <CreditCard className="w-4 h-4 text-green-400" />
                <span className="text-xs text-gray-400">المبلغ</span>
              </div>
              <p className="text-white text-sm font-semibold">{request.amount} ريال</p>
            </div>
          </div>
        </motion.div>

        {/* Status Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <OrderStatusTimeline 
            status={request.status} 
            deliveryMethod={request.delivery_method}
          />
        </motion.div>

        {/* Delivery Tracking or Branch Status */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          {request.delivery_method === 'express' && request.status === 'out_for_delivery' ? (
            <DeliveryTracking 
              deliveryAddress={
                request.delivery_address 
                  ? `${request.delivery_address.street}, ${request.delivery_address.district}, ${request.delivery_address.city}`
                  : 'العنوان غير متوفر'
              }
            />
          ) : (
            <BranchStatus 
              branch={request.branch_name}
              status={request.status}
            />
          )}
        </motion.div>

        {/* Need Help Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-[#1a1a1a] rounded-3xl p-5 border border-[#2a2a2a]"
        >
          <h3 className="text-white font-bold mb-3">هل تحتاج مساعدة؟</h3>
          <p className="text-gray-400 text-sm mb-4">
            فريق الدعم متاح للإجابة على استفساراتك
          </p>
          <div className="flex gap-3">
            <Button className="flex-1 bg-blue-600 hover:bg-blue-700 h-11">
              اتصل بالدعم
            </Button>
            <Button variant="outline" className="flex-1 border-[#2a2a2a] hover:bg-[#2a2a2a] h-11">
              الأسئلة الشائعة
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}