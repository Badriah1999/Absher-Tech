import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { 
  ChevronRight, Shield, Clock, CheckCircle, AlertCircle, 
  Package, MapPin, CreditCard, Calendar, FileText, Loader2,
  Building2, Truck, XCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import NotificationBell from '@/components/notifications/NotificationBell';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

export default function Requests() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: requests = [], isLoading } = useQuery({
    queryKey: ['requests', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      return await base44.entities.Request.filter(
        { user_email: user.email },
        '-created_date',
        50
      );
    },
    enabled: !!user?.email,
  });

  const getStatusInfo = (status) => {
    const statusMap = {
      pending: { 
        label: 'قيد الانتظار', 
        color: 'bg-slate-100 text-slate-700 border-slate-200',
        icon: Clock,
        iconColor: 'text-slate-500'
      },
      processing: { 
        label: 'قيد المعالجة', 
        color: 'bg-blue-100 text-blue-700 border-blue-200',
        icon: Loader2,
        iconColor: 'text-blue-500'
      },
      payment_pending: { 
        label: 'في انتظار الدفع', 
        color: 'bg-amber-100 text-amber-700 border-amber-200',
        icon: CreditCard,
        iconColor: 'text-amber-500'
      },
      paid: { 
        label: 'تم الدفع', 
        color: 'bg-emerald-100 text-emerald-700 border-emerald-200',
        icon: CheckCircle,
        iconColor: 'text-emerald-500'
      },
      ready_for_pickup: { 
        label: 'جاهز للاستلام', 
        color: 'bg-purple-100 text-purple-700 border-purple-200',
        icon: Package,
        iconColor: 'text-purple-500'
      },
      completed: { 
        label: 'مكتمل', 
        color: 'bg-green-100 text-green-700 border-green-200',
        icon: CheckCircle,
        iconColor: 'text-green-500'
      },
      cancelled: { 
        label: 'ملغي', 
        color: 'bg-red-100 text-red-700 border-red-200',
        icon: XCircle,
        iconColor: 'text-red-500'
      }
    };
    return statusMap[status] || statusMap.pending;
  };

  const getRequestTypeLabel = (type) => {
    const typeMap = {
      renewal: 'تجديد الهوية',
      new: 'إصدار هوية جديدة',
      replacement: 'بدل فاقد/تالف'
    };
    return typeMap[type] || type;
  };

  const formatDate = (dateString) => {
    try {
      return format(new Date(dateString), 'dd MMMM yyyy - hh:mm a', { locale: ar });
    } catch {
      return dateString;
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a]" dir="rtl">
      {/* Header */}
      <div className="bg-[#0a0a0a] text-white px-6 py-6">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl('Notification')}>
              <button className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
                <ChevronRight className="w-5 h-5" />
              </button>
            </Link>
            <div className="flex-1">
              <h1 className="text-xl font-bold">طلباتي</h1>
              <p className="text-white/70 text-sm">تتبع حالة طلباتك</p>
            </div>
            <NotificationBell />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-md mx-auto px-6 py-6">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 text-[#b4ff00] animate-spin" />
          </div>
        ) : requests.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-[#1a1a1a] rounded-3xl border border-[#2a2a2a] p-12 text-center"
          >
            <FileText className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-white font-semibold text-lg mb-2">لا توجد طلبات</h3>
            <p className="text-gray-400 text-sm mb-6">لم تقم بتقديم أي طلبات بعد</p>
            <Link to={createPageUrl('Notification')}>
              <Button className="bg-[#1a3d1a] hover:bg-[#234d23] text-white">
                تقديم طلب جديد
              </Button>
            </Link>
          </motion.div>
        ) : (
          <div className="space-y-4">
            {requests.map((request, index) => {
              const statusInfo = getStatusInfo(request.status);
              const StatusIcon = statusInfo.icon;
              
              return (
                <Link key={request.id} to={createPageUrl('RequestTracking') + `?ref=${request.reference_number}`}>
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ 
                      type: "spring",
                      stiffness: 300,
                      damping: 25,
                      delay: index * 0.05
                    }}
                    whileHover={{ scale: 1.02 }}
                    className="bg-[#1a1a1a] rounded-3xl border border-[#2a2a2a] overflow-hidden hover:border-[#3a3a3a] transition-colors cursor-pointer"
                  >
                  {/* Request Header */}
                  <div className="p-6 border-b border-[#2a2a2a]">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-2xl bg-[#b4ff00]/10 flex items-center justify-center">
                          <Shield className="w-6 h-6 text-[#b4ff00]" />
                        </div>
                        <div>
                          <h3 className="font-bold text-white">
                            {getRequestTypeLabel(request.request_type)}
                          </h3>
                          <p className="text-gray-400 text-xs font-mono">
                            {request.reference_number}
                          </p>
                        </div>
                      </div>
                      <Badge className={`${statusInfo.color} border flex items-center gap-1.5 px-3 py-1`}>
                        <StatusIcon className={`w-3.5 h-3.5 ${statusInfo.iconColor} ${request.status === 'processing' ? 'animate-spin' : ''}`} />
                        {statusInfo.label}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-gray-500 text-xs">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>{formatDate(request.created_date)}</span>
                    </div>
                  </div>

                  {/* Request Details */}
                  <div className="p-6 space-y-3">
                    {/* Payment Info */}
                    <div className="flex items-center justify-between py-2">
                      <div className="flex items-center gap-2 text-gray-400 text-sm">
                        <CreditCard className="w-4 h-4" />
                        <span>المبلغ</span>
                      </div>
                      <span className="font-semibold text-white">{request.amount} ريال</span>
                    </div>

                    {/* Delivery Method */}
                    {request.delivery_method && (
                      <div className="flex items-center justify-between py-2">
                        <div className="flex items-center gap-2 text-gray-400 text-sm">
                          <MapPin className="w-4 h-4" />
                          <span>طريقة الاستلام</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {request.delivery_method === 'branch' ? (
                            <>
                              <Building2 className="w-4 h-4 text-gray-400" />
                              <span className="text-white text-sm">
                                {request.branch_name || 'من الفرع'}
                              </span>
                            </>
                          ) : (
                            <>
                              <Truck className="w-4 h-4 text-gray-400" />
                              <span className="text-white text-sm">توصيل سريع</span>
                            </>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Payment Method */}
                    {request.payment_method && (
                      <div className="flex items-center justify-between py-2">
                        <div className="flex items-center gap-2 text-gray-400 text-sm">
                          <CreditCard className="w-4 h-4" />
                          <span>طريقة الدفع</span>
                        </div>
                        <span className="text-white text-sm">
                          {request.payment_method === 'card' ? 'مدى/بطاقة' : 'سداد'}
                        </span>
                      </div>
                    )}

                    {/* Sadad Bill Number */}
                    {request.sadad_bill_number && (
                      <div className="mt-3 pt-3 border-t border-[#2a2a2a]">
                        <div className="bg-[#2a2a2a] rounded-2xl p-4">
                          <p className="text-gray-400 text-xs mb-2">رقم فاتورة سداد</p>
                          <p className="text-white font-mono text-lg font-semibold" dir="ltr">
                            {request.sadad_bill_number}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                  </motion.div>
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}