import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ChevronRight, Check, Loader2, Database, FileUp, 
  Calendar, CreditCard, Shield, Lock, X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import NotificationBell from '@/components/notifications/NotificationBell';

const steps = [
  { id: 1, title: 'جمع البيانات', description: 'استرجاع المعلومات الشخصية', icon: Database },
  { id: 2, title: 'تحميل الوثائق', description: 'رفع الصورة والمستندات', icon: FileUp },
  { id: 3, title: 'جدولة الموعد', description: 'حجز موعد التسليم', icon: Calendar },
  { id: 4, title: 'في انتظار الدفع', description: 'إتمام عملية الدفع', icon: CreditCard },
];

// Get payment method from URL params - always sadad
const getPaymentMethod = () => {
  return 'sadad';
};

export default function Progress() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [showPayment, setShowPayment] = useState(false);
  const [paymentProcessing, setPaymentProcessing] = useState(false);
  const [user, setUser] = useState(null);
  const [paymentMethod] = useState(getPaymentMethod());
  const [sadadBillNumber] = useState(() => {
    // Generate random SADAD bill number
    return '1' + Math.floor(Math.random() * 10000000000).toString().padStart(10, '0');
  });

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  useEffect(() => {
    if (currentStep < 3) {
      const timer = setTimeout(() => {
        setCurrentStep(prev => prev + 1);
      }, 1500);
      return () => clearTimeout(timer);
    } else if (currentStep === 3) {
      const timer = setTimeout(() => {
        setShowPayment(true);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [currentStep]);

  const handlePayment = async () => {
    setPaymentProcessing(true);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Send success notification
      if (user?.email) {
        await base44.entities.Notification.create({
          title: 'تم إنشاء فاتورة سداد',
          message: `تم إنشاء فاتورة سداد برقم ${sadadBillNumber}. يرجى الدفع خلال 72 ساعة.`,
          type: 'success',
          category: 'payment',
          user_email: user.email,
          action_url: createPageUrl('Completion')
        });
      }
      
      setShowPayment(false);
      setCurrentStep(4);
      await new Promise(resolve => setTimeout(resolve, 1000));
      navigate(createPageUrl('Completion') + '?payment=sadad&bill=' + sadadBillNumber);
    } catch (error) {
      // Send error notification
      if (user?.email) {
        await base44.entities.Notification.create({
          title: 'فشل في إنشاء الفاتورة',
          message: 'حدث خطأ أثناء إنشاء فاتورة سداد. يرجى المحاولة مرة أخرى.',
          type: 'error',
          category: 'payment',
          user_email: user.email,
          action_url: createPageUrl('Progress')
        });
      }
      setPaymentProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-l from-[#1e3a5f] to-[#2d4a6f] text-white px-6 py-6">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl('Approvals')}>
              <button className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
                <ChevronRight className="w-5 h-5" />
              </button>
            </Link>
            <div className="flex-1">
              <h1 className="text-xl font-bold">معالجة الطلب</h1>
              <p className="text-white/70 text-sm">جاري تنفيذ الخطوات تلقائياً</p>
            </div>
            <NotificationBell />
          </div>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="max-w-md mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {[1, 2, 3, 4].map((step, index) => (
            <React.Fragment key={step}>
              <div className="flex flex-col items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold transition-all ${
                  step <= 3 ? 'bg-[#059669] text-white' : 'bg-slate-200 text-slate-400'
                }`}>
                  {step < 3 ? <Check className="w-4 h-4" /> : step}
                </div>
              </div>
              {index < 3 && (
                <div className={`flex-1 h-1 mx-2 rounded-full ${
                  step < 3 ? 'bg-[#059669]' : 'bg-slate-200'
                }`} />
              )}
            </React.Fragment>
          ))}
        </div>
        <div className="flex justify-between mt-2 px-1">
          <span className="text-xs text-slate-500">التنبيه</span>
          <span className="text-xs text-slate-500">الخيارات</span>
          <span className="text-xs text-[#059669] font-medium">المعالجة</span>
          <span className="text-xs text-slate-400">الإتمام</span>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-md mx-auto px-6 py-6">
        {/* Automation Status Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl shadow-xl shadow-slate-200/50 overflow-hidden mb-6"
        >
          <div className="bg-gradient-to-l from-blue-500 to-indigo-500 p-5 text-white">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <Shield className="w-6 h-6" />
              </div>
              <div>
                <h2 className="font-bold text-lg">الأتمتة نشطة</h2>
                <p className="text-white/80 text-sm">جاري تنفيذ الخطوات...</p>
              </div>
            </div>
          </div>

          <div className="p-6 space-y-4">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isCompleted = index < currentStep;
              const isCurrent = index === currentStep;
              const isPending = index > currentStep;

              return (
                <motion.div
                  key={step.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`flex items-center gap-4 p-4 rounded-2xl transition-all duration-300 ${
                    isCompleted ? 'bg-emerald-50' : 
                    isCurrent ? 'bg-amber-50 border-2 border-amber-200' : 
                    'bg-slate-50'
                  }`}
                >
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${
                    isCompleted ? 'bg-[#059669]' :
                    isCurrent ? 'bg-amber-500' :
                    'bg-slate-200'
                  }`}>
                    {isCompleted ? (
                      <Check className="w-6 h-6 text-white" />
                    ) : isCurrent ? (
                      <Loader2 className="w-6 h-6 text-white animate-spin" />
                    ) : (
                      <Icon className="w-6 h-6 text-slate-400" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className={`font-semibold ${
                      isCompleted ? 'text-[#059669]' :
                      isCurrent ? 'text-amber-700' :
                      'text-slate-400'
                    }`}>
                      {step.title}
                    </p>
                    <p className={`text-sm ${
                      isCompleted ? 'text-emerald-600' :
                      isCurrent ? 'text-amber-600' :
                      'text-slate-400'
                    }`}>
                      {isCompleted ? 'تم بنجاح' :
                       isCurrent ? 'جاري التنفيذ...' :
                       step.description}
                    </p>
                  </div>
                  {isCompleted && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="text-[#059669]"
                    >
                      ✓
                    </motion.div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Info Box */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="bg-blue-50 rounded-2xl p-4 border border-blue-100"
        >
          <p className="text-sm text-slate-600 text-center">
            يرجى عدم إغلاق التطبيق حتى إتمام جميع الخطوات
          </p>
        </motion.div>
      </div>

      {/* Payment Dialog */}
      <Dialog open={showPayment} onOpenChange={setShowPayment}>
        <DialogContent className="sm:max-w-md mx-4 rounded-3xl p-0 overflow-hidden" dir="rtl">
          <div className="bg-gradient-to-l from-[#1e3a5f] to-[#2d4a6f] p-6 text-white">
            <DialogHeader>
              <DialogTitle className="text-xl font-bold text-white flex items-center gap-3">
                <Lock className="w-5 h-5" />
                فاتورة سداد
              </DialogTitle>
            </DialogHeader>
            <p className="text-white/70 text-sm mt-2">
              رقم الفاتورة للدفع عبر أجهزة الصراف
            </p>
          </div>
          
          <div className="p-6 space-y-5">
            <div className="bg-slate-50 rounded-2xl p-4 flex justify-between items-center">
              <span className="text-slate-600">المبلغ المطلوب</span>
              <span className="text-2xl font-bold text-slate-800">100 ريال</span>
            </div>

            <>
                <div className="space-y-4">
                  <div className="bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-300 rounded-2xl p-6">
                    <p className="text-slate-600 text-sm text-center mb-3">رقم الفاتورة</p>
                    <div className="bg-white rounded-xl p-4 text-center">
                      <p className="text-3xl font-bold text-slate-800 tracking-wider font-mono" dir="ltr">
                        {sadadBillNumber}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        navigator.clipboard.writeText(sadadBillNumber);
                      }}
                      className="w-full mt-3 h-9 text-orange-700 hover:text-orange-800 hover:bg-orange-200"
                    >
                      نسخ رقم الفاتورة
                    </Button>
                  </div>

                  <div className="bg-blue-50 rounded-2xl p-4 border border-blue-200">
                    <h4 className="font-semibold text-slate-800 mb-2 text-sm">كيفية الدفع:</h4>
                    <ul className="space-y-2 text-xs text-slate-600">
                      <li className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
                        <span>توجه إلى أقرب جهاز صراف آلي</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
                        <span>اختر خدمة سداد من القائمة</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
                        <span>أدخل رقم الفاتورة المذكور أعلاه</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
                        <span>أكمل عملية الدفع</span>
                      </li>
                    </ul>
                  </div>

                  <div className="bg-amber-50 rounded-2xl p-3 border border-amber-200">
                    <p className="text-xs text-amber-800 text-center">
                      <span className="font-semibold">مهم:</span> يجب إتمام الدفع خلال 72 ساعة
                    </p>
                  </div>
                </div>

                <Button
                  onClick={handlePayment}
                  disabled={paymentProcessing}
                  className="w-full h-14 text-lg font-semibold bg-gradient-to-l from-[#059669] to-[#10b981] hover:from-[#047857] hover:to-[#059669] rounded-2xl shadow-lg shadow-emerald-500/25"
                >
                  {paymentProcessing ? (
                    <>
                      <Loader2 className="w-5 h-5 ml-2 animate-spin" />
                      جاري الحفظ...
                    </>
                  ) : (
                    <>
                      <Check className="w-5 h-5 ml-2" />
                      حفظ رقم الفاتورة
                    </>
                  )}
                </Button>
              </>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}