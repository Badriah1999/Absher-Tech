import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { 
  ChevronRight, MapPin, Building2, Truck, Check, Sparkles,
  Navigation, Edit, Star
} from 'lucide-react';
import Tooltip from '@/components/ui/Tooltip';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import NotificationBell from '@/components/notifications/NotificationBell';

export default function DeliverySelection() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [deliveryMethod, setDeliveryMethod] = useState('branch');
  const [confirmed, setConfirmed] = useState(false);
  const [showBranchList, setShowBranchList] = useState(false);
  const [userLocation, setUserLocation] = useState(null);
  
  // Get bill number from URL
  const params = new URLSearchParams(window.location.search);
  const billNumber = params.get('bill');

  // Available branches with detailed info
  const allBranches = [
    {
      id: 1,
      name: 'فرع الرياض - العليا',
      distance: '3.2 كم',
      travelTime: '8 دقائق',
      crowdLevel: 'منخفض',
      address: 'طريق الملك فهد، حي العليا',
      workingHours: '8:00 ص - 8:00 م',
      isOpen: true,
      lat: 24.7136,
      lng: 46.6753
    },
    {
      id: 2,
      name: 'فرع الرياض - النخيل',
      distance: '5.8 كم',
      travelTime: '15 دقيقة',
      crowdLevel: 'متوسط',
      address: 'شارع الأمير محمد بن عبدالعزيز، حي النخيل',
      workingHours: '8:00 ص - 8:00 م',
      isOpen: true,
      lat: 24.7459,
      lng: 46.6766
    },
    {
      id: 3,
      name: 'فرع الرياض - الملز',
      distance: '7.1 كم',
      travelTime: '18 دقيقة',
      crowdLevel: 'مرتفع',
      address: 'طريق الملك عبدالعزيز، حي الملز',
      workingHours: '8:00 ص - 8:00 م',
      isOpen: true,
      lat: 24.6877,
      lng: 46.7219
    },
    {
      id: 4,
      name: 'فرع الرياض - الياسمين',
      distance: '4.5 كم',
      travelTime: '12 دقيقة',
      crowdLevel: 'منخفض',
      address: 'شارع عثمان بن عفان، حي الياسمين',
      workingHours: '8:00 ص - 8:00 م',
      isOpen: true,
      lat: 24.7742,
      lng: 46.6977
    }
  ];

  const [selectedBranch, setSelectedBranch] = useState(allBranches[0]);

  // National Address
  const nationalAddress = {
    street: 'شارع الأمير محمد بن عبدالعزيز',
    district: 'حي النخيل',
    city: 'الرياض',
    postalCode: '12345',
    buildingNumber: '7821'
  };

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
    
    // Get user location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.log('Location access denied');
        }
      );
    }
  }, []);

  const handleSubmit = async () => {
    if (!confirmed) return;

    // Create request
    const referenceNumber = 'ID-' + new Date().getFullYear() + '-' + Math.floor(Math.random() * 900000 + 100000);
    
    if (user?.email) {
      await base44.entities.Request.create({
        reference_number: referenceNumber,
        request_type: 'renewal',
        status: 'payment_pending',
        payment_method: 'sadad',
        payment_status: 'pending',
        amount: 100,
        delivery_method: deliveryMethod,
        branch_name: deliveryMethod === 'branch' ? selectedBranch.name : null,
        delivery_address: deliveryMethod === 'express' ? nationalAddress : null,
        sadad_bill_number: billNumber,
        user_email: user.email
      });

      await base44.entities.Notification.create({
        title: 'تم استلام طلب التجديد',
        message: `تم تقديم طلب التجديد برقم ${referenceNumber}. سيتم إشعارك بأي تحديثات.`,
        type: 'success',
        category: 'renewal',
        user_email: user.email,
        action_url: createPageUrl('SubmitConfirmation') + `?ref=${referenceNumber}`
      });
    }

    navigate(createPageUrl('SubmitConfirmation') + `?ref=${referenceNumber}`);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a]" dir="rtl">
      {/* Header */}
      <div className="bg-[#0a0a0a] text-white px-6 py-6">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl('PaymentSadad')}>
              <button className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
                <ChevronRight className="w-5 h-5" />
              </button>
            </Link>
            <div className="flex-1">
              <h1 className="text-xl font-bold">اختيار طريقة الاستلام</h1>
              <p className="text-white/70 text-sm">كيف تريد استلام هويتك؟</p>
            </div>
            <NotificationBell />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-md mx-auto px-6 py-6">
        <RadioGroup value={deliveryMethod} onValueChange={setDeliveryMethod} className="space-y-4 mb-6">
          {/* Branch Pickup Option */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Label
              htmlFor="branch"
              className={`block p-6 rounded-3xl border-2 cursor-pointer transition-all ${
                deliveryMethod === 'branch' 
                  ? 'border-[#b4ff00] bg-[#b4ff00]/5' 
                  : 'border-[#2a2a2a] hover:border-[#3a3a3a] bg-[#1a1a1a]'
              }`}
            >
              <div className="flex items-start gap-4 mb-4">
                <RadioGroupItem value="branch" id="branch" className="mt-1" />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Star className="w-5 h-5 text-[#b4ff00]" />
                    <Tooltip text="تم اختيار هذا الفرع تلقائياً بناءً على موقعك الحالي، مستوى الازدحام، وأوقات العمل المتاحة باستخدام الذكاء الاصطناعي.">
                      <h3 className="font-bold text-white">الفرع المقترح من أبشر بوت</h3>
                    </Tooltip>
                  </div>
                  <p className="text-sm text-gray-400">تم اختياره تلقائياً بالذكاء الاصطناعي</p>
                </div>
                {deliveryMethod === 'branch' && (
                  <div className="w-6 h-6 rounded-full bg-[#b4ff00] flex items-center justify-center">
                    <Check className="w-4 h-4 text-black" />
                  </div>
                )}
              </div>

              {/* Branch Details */}
              <div className="bg-[#2a2a2a] rounded-2xl p-4 border border-[#3a3a3a] space-y-4">
                <div className="flex items-start gap-3">
                  <Building2 className="w-5 h-5 text-[#b4ff00] flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="font-semibold text-white mb-1">{selectedBranch.name}</p>
                    <p className="text-sm text-gray-400">{selectedBranch.address}</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-3 pt-3 border-t border-[#3a3a3a]">
                  <div className="flex items-center gap-2">
                    <Navigation className="w-4 h-4 text-blue-400" />
                    <div>
                      <p className="text-xs text-gray-500">المسافة</p>
                      <p className="text-sm font-semibold text-gray-300">{selectedBranch.distance}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-400" />
                    <div>
                      <p className="text-xs text-gray-500">الوصول</p>
                      <p className="text-sm font-semibold text-gray-300">{selectedBranch.travelTime}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-green-400" />
                    <div>
                      <p className="text-xs text-gray-500">الازدحام</p>
                      <p className="text-sm font-semibold text-gray-300">{selectedBranch.crowdLevel}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-purple-400" />
                    <div>
                      <p className="text-xs text-gray-500">أوقات العمل</p>
                      <p className="text-xs font-semibold text-green-400">مفتوح الآن</p>
                    </div>
                  </div>
                </div>

                {/* Map */}
                <div className="pt-3 border-t border-[#3a3a3a]">
                  <BranchMap branch={selectedBranch} userLocation={userLocation} />
                </div>

                <Button
                  type="button"
                  onClick={() => setShowBranchList(true)}
                  variant="ghost"
                  size="sm"
                  className="w-full h-10 text-sm text-gray-400 hover:text-white hover:bg-[#3a3a3a]"
                >
                  <Edit className="w-3.5 h-3.5 ml-1.5" />
                  تغيير الفرع ({allBranches.length} فروع متاحة)
                </Button>
              </div>
            </Label>
          </motion.div>

          {/* Home Delivery Option */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Label
              htmlFor="express"
              className={`block p-6 rounded-3xl border-2 cursor-pointer transition-all ${
                deliveryMethod === 'express' 
                  ? 'border-[#b4ff00] bg-[#b4ff00]/5' 
                  : 'border-[#2a2a2a] hover:border-[#3a3a3a] bg-[#1a1a1a]'
              }`}
            >
              <div className="flex items-start gap-4 mb-4">
                <RadioGroupItem value="express" id="express" className="mt-1" />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Truck className="w-5 h-5 text-purple-400" />
                    <h3 className="font-bold text-white">التوصيل للعنوان الوطني</h3>
                  </div>
                  <p className="text-sm text-gray-400">توصيل لعنوانك خلال 3-5 أيام</p>
                </div>
                {deliveryMethod === 'express' && (
                  <div className="w-6 h-6 rounded-full bg-[#b4ff00] flex items-center justify-center">
                    <Check className="w-4 h-4 text-black" />
                  </div>
                )}
              </div>

              {/* Address Details */}
              <div className="bg-[#2a2a2a] rounded-2xl p-4 border border-[#3a3a3a]">
                <div className="flex items-start gap-3 mb-3">
                  <MapPin className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-white font-semibold mb-2">العنوان الوطني</p>
                    <div className="space-y-1 text-sm text-gray-300">
                      <p>{nationalAddress.street}</p>
                      <p>{nationalAddress.district}، {nationalAddress.city}</p>
                      <p>الرمز البريدي: {nationalAddress.postalCode}</p>
                      <p>رقم المبنى: {nationalAddress.buildingNumber}</p>
                    </div>
                  </div>
                </div>

                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="w-full mt-3 h-9 text-sm text-gray-400 hover:text-white hover:bg-[#3a3a3a]"
                >
                  <Edit className="w-3.5 h-3.5 ml-1.5" />
                  تعديل العنوان
                </Button>
              </div>

              <div className="mt-3 bg-amber-500/10 rounded-xl p-3 border border-amber-500/20">
                <p className="text-xs text-amber-400">
                  قد تُفرض رسوم توصيل إضافية (50 ريال)
                </p>
              </div>
            </Label>
          </motion.div>
        </RadioGroup>

        {/* Confirmation Checkbox */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-[#1a1a1a] rounded-2xl p-5 border border-[#2a2a2a] mb-6"
        >
          <div className="flex items-start gap-3">
            <Checkbox
              id="confirm"
              checked={confirmed}
              onCheckedChange={setConfirmed}
              className="mt-0.5"
            />
            <Label htmlFor="confirm" className="text-sm text-gray-300 cursor-pointer flex-1">
              أقر بصحة البيانات وأوافق على طريقة الاستلام المختارة
            </Label>
          </div>
        </motion.div>

        {/* Submit Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Button
            onClick={handleSubmit}
            disabled={!confirmed}
            className="w-full h-14 text-lg font-semibold bg-[#1a3d1a] hover:bg-[#234d23] text-white rounded-2xl disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Sparkles className="w-5 h-5 ml-2" />
            تأكيد وإرسال طلب التجديد
          </Button>
        </motion.div>
      </div>

      {/* Branch List Modal */}
      <AnimatePresence>
        {showBranchList && (
          <BranchList
            branches={allBranches}
            selectedBranch={selectedBranch}
            onSelectBranch={(branch) => {
              setSelectedBranch(branch);
              setShowBranchList(false);
            }}
            onClose={() => setShowBranchList(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}