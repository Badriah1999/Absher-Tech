import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { 
  ChevronRight, Bell, CheckCircle, AlertCircle, Info,
  Trash2, Check, Filter
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function Notifications() {
  const [user, setUser] = useState(null);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: notifications = [], refetch } = useQuery({
    queryKey: ['notifications', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      const allNotifications = await base44.entities.Notification.filter(
        { user_email: user.email },
        '-created_date',
        100
      );
      return allNotifications;
    },
    enabled: !!user?.email,
  });

  const filteredNotifications = notifications.filter(n => {
    if (filter === 'unread') return !n.is_read;
    if (filter === 'read') return n.is_read;
    return true;
  });

  const markAsRead = async (notificationId) => {
    await base44.entities.Notification.update(notificationId, { is_read: true });
    refetch();
  };

  const deleteNotification = async (notificationId) => {
    await base44.entities.Notification.delete(notificationId);
    refetch();
  };

  const markAllAsRead = async () => {
    const unreadNotifications = notifications.filter(n => !n.is_read);
    await Promise.all(
      unreadNotifications.map(n => 
        base44.entities.Notification.update(n.id, { is_read: true })
      )
    );
    refetch();
  };

  const getIcon = (type) => {
    switch (type) {
      case 'success': return <CheckCircle className="w-6 h-6 text-green-500" />;
      case 'warning': return <AlertCircle className="w-6 h-6 text-amber-500" />;
      case 'error': return <AlertCircle className="w-6 h-6 text-red-500" />;
      default: return <Info className="w-6 h-6 text-blue-500" />;
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'success': return 'bg-green-50 border-green-200';
      case 'warning': return 'bg-amber-50 border-amber-200';
      case 'error': return 'bg-red-50 border-red-200';
      default: return 'bg-blue-50 border-blue-200';
    }
  };

  const getTimeAgo = (date) => {
    const now = new Date();
    const notifDate = new Date(date);
    const diffMs = now - notifDate;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'الآن';
    if (diffMins < 60) return `منذ ${diffMins} دقيقة`;
    if (diffHours < 24) return `منذ ${diffHours} ساعة`;
    return `منذ ${diffDays} يوم`;
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-l from-[#1e3a5f] to-[#2d4a6f] text-white px-6 py-6">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl('Notification')}>
              <button className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
                <ChevronRight className="w-5 h-5" />
              </button>
            </Link>
            <div className="flex-1">
              <h1 className="text-xl font-bold">الإشعارات</h1>
              <p className="text-white/70 text-sm">
                {unreadCount > 0 ? `${unreadCount} إشعار غير مقروء` : 'جميع الإشعارات مقروءة'}
              </p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center">
              <Bell className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="max-w-md mx-auto px-6 py-4">
        <div className="flex items-center justify-between gap-4">
          <Tabs value={filter} onValueChange={setFilter} className="flex-1">
            <TabsList className="grid w-full grid-cols-3 bg-slate-100">
              <TabsTrigger value="all">الكل ({notifications.length})</TabsTrigger>
              <TabsTrigger value="unread">غير مقروءة ({unreadCount})</TabsTrigger>
              <TabsTrigger value="read">مقروءة ({notifications.length - unreadCount})</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
        
        {unreadCount > 0 && (
          <div className="mt-3">
            <Button
              variant="outline"
              size="sm"
              onClick={markAllAsRead}
              className="w-full h-9 rounded-xl border-2 border-slate-200 hover:border-[#059669] hover:bg-emerald-50"
            >
              <Check className="w-4 h-4 ml-2" />
              تعليم الكل كمقروء
            </Button>
          </div>
        )}
      </div>

      {/* Notifications List */}
      <div className="max-w-md mx-auto px-6 pb-8">
        {filteredNotifications.length === 0 ? (
          <div className="bg-white rounded-3xl shadow-lg shadow-slate-100 p-12 text-center">
            <div className="w-20 h-20 rounded-full bg-slate-100 mx-auto mb-4 flex items-center justify-center">
              <Bell className="w-10 h-10 text-slate-400" />
            </div>
            <p className="text-slate-500">
              {filter === 'unread' ? 'لا توجد إشعارات غير مقروءة' : 
               filter === 'read' ? 'لا توجد إشعارات مقروءة' :
               'لا توجد إشعارات'}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredNotifications.map((notification, index) => (
              <motion.div
                key={notification.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`bg-white rounded-2xl shadow-md shadow-slate-100 overflow-hidden ${
                  !notification.is_read ? 'border-2 border-blue-200' : 'border border-slate-100'
                }`}
              >
                <div className="p-4">
                  <div className="flex gap-3">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
                      getTypeColor(notification.type)
                    }`}>
                      {getIcon(notification.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h3 className="font-bold text-slate-800">
                          {notification.title}
                        </h3>
                        {!notification.is_read && (
                          <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0 mt-2" />
                        )}
                      </div>
                      <p className="text-slate-600 text-sm leading-relaxed mb-2">
                        {notification.message}
                      </p>
                      <p className="text-slate-400 text-xs">
                        {getTimeAgo(notification.created_date)}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 mt-3 pt-3 border-t border-slate-100">
                    {!notification.is_read && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => markAsRead(notification.id)}
                        className="flex-1 h-9 text-sm text-[#059669] hover:text-[#047857] hover:bg-emerald-50"
                      >
                        <Check className="w-4 h-4 ml-1" />
                        تعليم كمقروء
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteNotification(notification.id)}
                      className="flex-1 h-9 text-sm text-red-500 hover:text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4 ml-1" />
                      حذف
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}