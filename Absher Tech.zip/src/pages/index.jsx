import Layout from "./Layout.jsx";

import Notification from "./Notification";

import Approvals from "./Approvals";

import Progress from "./Progress";

import Completion from "./Completion";

import Notifications from "./Notifications";

import Demo from "./Demo";

import Requests from "./Requests";

import AutoRenewConfirmation from "./AutoRenewConfirmation";

import PhotoSelection from "./PhotoSelection";

import PhotoUpload from "./PhotoUpload";

import PaymentSadad from "./PaymentSadad";

import DeliverySelection from "./DeliverySelection";

import SubmitConfirmation from "./SubmitConfirmation";

import RequestTracking from "./RequestTracking";

import PaymentConfirmation from "./PaymentConfirmation";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Notification: Notification,
    
    Approvals: Approvals,
    
    Progress: Progress,
    
    Completion: Completion,
    
    Notifications: Notifications,
    
    Demo: Demo,
    
    Requests: Requests,
    
    AutoRenewConfirmation: AutoRenewConfirmation,
    
    PhotoSelection: PhotoSelection,
    
    PhotoUpload: PhotoUpload,
    
    PaymentSadad: PaymentSadad,
    
    DeliverySelection: DeliverySelection,
    
    SubmitConfirmation: SubmitConfirmation,
    
    RequestTracking: RequestTracking,
    
    PaymentConfirmation: PaymentConfirmation,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Notification />} />
                
                
                <Route path="/Notification" element={<Notification />} />
                
                <Route path="/Approvals" element={<Approvals />} />
                
                <Route path="/Progress" element={<Progress />} />
                
                <Route path="/Completion" element={<Completion />} />
                
                <Route path="/Notifications" element={<Notifications />} />
                
                <Route path="/Demo" element={<Demo />} />
                
                <Route path="/Requests" element={<Requests />} />
                
                <Route path="/AutoRenewConfirmation" element={<AutoRenewConfirmation />} />
                
                <Route path="/PhotoSelection" element={<PhotoSelection />} />
                
                <Route path="/PhotoUpload" element={<PhotoUpload />} />
                
                <Route path="/PaymentSadad" element={<PaymentSadad />} />
                
                <Route path="/DeliverySelection" element={<DeliverySelection />} />
                
                <Route path="/SubmitConfirmation" element={<SubmitConfirmation />} />
                
                <Route path="/RequestTracking" element={<RequestTracking />} />
                
                <Route path="/PaymentConfirmation" element={<PaymentConfirmation />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}