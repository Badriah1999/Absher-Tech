import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { 
  ChevronRight, CreditCard, Copy, Check, Info, ArrowLeft
} from 'lucide-react';
import Tooltip from '@/components/ui/Tooltip';
import { Button } from '@/components/ui/button';
import NotificationBell from '@/components/notifications/NotificationBell';
import { toast } from 'sonner';

export default function PaymentSadad() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [copied, setCopied] = useState(false);
  const serviceFee = 100;
  const sadadBillNumber = '1' + Math.floor(Math.random() * 10000000000).toString().padStart(10, '0');

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(sadadBillNumber);
    setCopied(true);
    toast.success('تم نسخ رقم الفاتورة');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleContinue = async () => {
    if (user?.email) {
      await base44.entities.Notification.create({
        title: 'تم إنشاء فاتورة سداد',
        message: `رقم الفاتورة: ${sadadBillNumber}. يرجى الدفع خلال 72 ساعة`,
        type: 'info',
        category: 'payment',
        user_email: user.email
      });
    }
    navigate(createPageUrl('DeliverySelection') + `?bill=${sadadBillNumber}`);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a]" dir="rtl">
      {/* Header */}
      <div className="bg-[#0a0a0a] text-white px-6 py-6">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl('PhotoSelection')}>
              <button className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
                <ChevronRight className="w-5 h-5" />
              </button>
            </Link>
            <div className="flex-1">
              <h1 className="text-xl font-bold">الدفع - فاتورة سداد</h1>
              <p className="text-white/70 text-sm">ادفع عبر تطبيق البنك أو الصراف</p>
            </div>
            <NotificationBell />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-md mx-auto px-6 py-6">
        {/* Service Fee Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#1a1a1a] rounded-3xl border border-[#2a2a2a] p-6 mb-6"
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-gray-400">رسوم الخدمة</span>
            <span className="text-3xl font-bold text-white">{serviceFee} ريال</span>
          </div>
          <div className="bg-amber-500/10 rounded-2xl p-3 border border-amber-500/20">
            <div className="flex items-center gap-2 text-amber-400 text-sm">
              <Info className="w-4 h-4 flex-shrink-0" />
              <span>في انتظار الدفع</span>
            </div>
          </div>
        </motion.div>

        {/* SADAD Bill Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-br from-orange-500/10 to-orange-600/10 border-2 border-orange-500/30 rounded-3xl p-6 mb-6"
        >
          <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-orange-400" />
            <Tooltip text="رقم فاتورة سداد هو رقم فريد يمكنك استخدامه للدفع عبر تطبيق البنك أو أجهزة الصراف الآلي. صالح لمدة 72 ساعة من وقت الإنشاء.">
              <span>رقم فاتورة سداد</span>
            </Tooltip>
          </h3>

          <div className="bg-[#1a1a1a] rounded-2xl p-5 mb-4">
            <p className="text-gray-400 text-xs text-center mb-2">رقم الفاتورة</p>
            <p className="text-3xl font-bold text-white text-center tracking-wider font-mono" dir="ltr">
              {sadadBillNumber}
            </p>
          </div>

          <Button
            onClick={handleCopy}
            variant="outline"
            className="w-full h-12 border-orange-500/30 bg-orange-500/10 text-orange-300 hover:bg-orange-500/20 hover:text-orange-200 rounded-2xl"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 ml-2" />
                تم النسخ
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 ml-2" />
                نسخ رقم الفاتورة
              </>
            )}
          </Button>
        </motion.div>

        {/* Instructions Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-[#1a1a1a] rounded-3xl border border-[#2a2a2a] p-6 mb-6"
        >
          <h3 className="text-white font-semibold mb-4">كيفية الدفع:</h3>
          <ul className="space-y-3">
            {[
              'يمكن الدفع عبر تطبيق البنك الخاص بك',
              'أو من خلال أجهزة الصرّاف الآلي',
              'ابحث عن خدمة "سداد"',
              'أدخل رقم الفاتورة المذكور أعلاه',
              'أكمل عملية الدفع'
            ].map((instruction, index) => (
              <li key={index} className="flex items-start gap-3 text-sm text-gray-300">
                <div className="w-6 h-6 rounded-full bg-[#b4ff00]/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-xs font-bold text-[#b4ff00]">{index + 1}</span>
                </div>
                <span>{instruction}</span>
              </li>
            ))}
          </ul>
        </motion.div>

        {/* Important Notice */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-blue-500/10 border border-blue-500/20 rounded-2xl p-4 mb-6"
        >
          <p className="text-sm text-blue-300 text-center">
            <span className="font-semibold">مهم:</span> يجب إتمام الدفع خلال 72 ساعة من إنشاء الفاتورة
          </p>
        </motion.div>

        {/* Continue Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Button
            onClick={handleContinue}
            className="w-full h-14 text-lg font-semibold bg-[#1a3d1a] hover:bg-[#234d23] text-white rounded-2xl"
          >
            متابعة إلى اختيار طريقة الاستلام
            <ArrowLeft className="w-5 h-5 mr-2" />
          </Button>
        </motion.div>
      </div>
    </div>
  );
}