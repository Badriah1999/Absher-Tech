import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { 
  PartyPopper, Shield, Calendar, MapPin, CreditCard, 
  FileText, Home, Building2, Truck
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import NotificationBell from '@/components/notifications/NotificationBell';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

export default function SubmitConfirmation() {
  const [request, setRequest] = useState(null);
  
  // Get reference number from URL
  const params = new URLSearchParams(window.location.search);
  const referenceNumber = params.get('ref');

  useEffect(() => {
    if (referenceNumber) {
      base44.entities.Request.filter(
        { reference_number: referenceNumber },
        '-created_date',
        1
      ).then(results => {
        if (results.length > 0) {
          setRequest(results[0]);
        }
      });
    }
  }, [referenceNumber]);

  const formatDate = (dateString) => {
    try {
      return format(new Date(dateString), 'dd MMMM yyyy - hh:mm a', { locale: ar });
    } catch {
      return dateString;
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a]" dir="rtl">
      {/* Header */}
      <div className="bg-[#0a0a0a] text-white px-6 py-6">
        <div className="max-w-md mx-auto">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold">تأكيد الطلب</h1>
            <NotificationBell />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-md mx-auto px-6 py-6">
        {/* Success Animation */}
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ 
            type: "spring",
            stiffness: 200,
            damping: 15
          }}
          className="flex justify-center mb-6"
        >
          <div className="w-32 h-32 rounded-full bg-gradient-to-br from-[#b4ff00]/20 to-[#059669]/20 flex items-center justify-center border-4 border-[#b4ff00]">
            <PartyPopper className="w-16 h-16 text-[#b4ff00]" />
          </div>
        </motion.div>

        {/* Success Message */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-center mb-8"
        >
          <h2 className="text-3xl font-bold text-white mb-3">
            تم استلام الطلب بنجاح!
          </h2>
          <p className="text-gray-400 text-lg">
            تم استلام طلب تجديد وثيقتك عبر أبشر-بوت
          </p>
          <p className="text-gray-500 text-sm mt-2">
            سيتم إشعارك عند أي تحديث على حالة الطلب
          </p>
        </motion.div>

        {/* Request Details Card */}
        {request && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-[#1a1a1a] rounded-3xl border border-[#2a2a2a] overflow-hidden mb-6"
          >
            <div className="bg-gradient-to-l from-[#b4ff00]/10 to-[#059669]/10 p-5 border-b border-[#2a2a2a]">
              <h3 className="text-white font-bold flex items-center gap-2">
                <Shield className="w-5 h-5 text-[#b4ff00]" />
                تفاصيل الطلب
              </h3>
            </div>

            <div className="p-6 space-y-4">
              {/* Reference Number */}
              <div className="flex items-center justify-between py-3 border-b border-[#2a2a2a]">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
                    <FileText className="w-5 h-5 text-blue-400" />
                  </div>
                  <span className="text-gray-400">رقم الطلب</span>
                </div>
                <span className="font-mono font-semibold text-white">{request.reference_number}</span>
              </div>

              {/* Date */}
              <div className="flex items-center justify-between py-3 border-b border-[#2a2a2a]">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-purple-400" />
                  </div>
                  <span className="text-gray-400">التاريخ</span>
                </div>
                <span className="text-white text-sm">{formatDate(request.created_date)}</span>
              </div>

              {/* Delivery Method */}
              <div className="flex items-center justify-between py-3 border-b border-[#2a2a2a]">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
                    {request.delivery_method === 'branch' ? (
                      <Building2 className="w-5 h-5 text-amber-400" />
                    ) : (
                      <Truck className="w-5 h-5 text-amber-400" />
                    )}
                  </div>
                  <span className="text-gray-400">طريقة الاستلام</span>
                </div>
                <div className="text-left">
                  <p className="text-white font-semibold">
                    {request.delivery_method === 'branch' ? 'من الفرع' : 'توصيل سريع'}
                  </p>
                  {request.branch_name && (
                    <p className="text-gray-400 text-xs">{request.branch_name}</p>
                  )}
                </div>
              </div>

              {/* Payment */}
              <div className="flex items-center justify-between py-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center">
                    <CreditCard className="w-5 h-5 text-green-400" />
                  </div>
                  <span className="text-gray-400">حالة الدفع</span>
                </div>
                <div className="text-left">
                  <p className="text-amber-400 font-semibold">في انتظار الدفع</p>
                  <p className="text-gray-500 text-xs">عبر سداد</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Next Steps Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="bg-blue-500/10 border border-blue-500/20 rounded-3xl p-6 mb-6"
        >
          <h3 className="text-white font-semibold mb-4">الخطوات القادمة:</h3>
          <ul className="space-y-3">
            {[
              'إتمام عملية الدفع عبر سداد خلال 72 ساعة',
              'سيبدأ أبشر-بوت بمعالجة طلبك تلقائياً',
              'سيتم إرسال تحديثات مستمرة عبر الإشعارات',
              'يمكنك متابعة حالة الطلب في أي وقت'
            ].map((step, index) => (
              <li key={index} className="flex items-start gap-3 text-sm text-gray-300">
                <div className="w-6 h-6 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-xs font-bold text-blue-400">{index + 1}</span>
                </div>
                <span>{step}</span>
              </li>
            ))}
          </ul>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          className="space-y-3"
        >
          <Link to={createPageUrl('Requests')}>
            <Button className="w-full h-14 text-lg font-semibold bg-[#1a3d1a] hover:bg-[#234d23] text-white rounded-2xl">
              <FileText className="w-5 h-5 ml-2" />
              عرض حالة الطلب
            </Button>
          </Link>

          <Link to={createPageUrl('Notification')}>
            <Button
              variant="outline"
              className="w-full h-14 text-lg font-semibold border-[#2a2a2a] bg-transparent text-white hover:bg-[#1a1a1a] rounded-2xl"
            >
              <Home className="w-5 h-5 ml-2" />
              عودة للرئيسية
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  );
}