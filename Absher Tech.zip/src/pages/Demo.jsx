import React from 'react';
import { motion } from 'framer-motion';
import { 
  AlertCircle, Clock, Sparkles, Camera, Upload, Check, MapPin, 
  CreditCard, Shield, Database, FileUp, Calendar, Loader2,
  PartyPopper, QrCode, Download, Share2, User, Building2, Truck,
  Info, Lock
} from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Demo() {
  return (
    <div className="min-h-screen bg-[#0a0a0a] py-8" dir="rtl">
      <div className="max-w-md mx-auto px-6 space-y-8">
        
        {/* Step 1: Notification */}
        <div className="space-y-4">
          <h2 className="text-2xl font-bold text-white text-center mb-6">الخطوة 1: التنبيه</h2>
          <div className="bg-[#1a1a1a] rounded-3xl shadow-xl shadow-black/50 overflow-hidden border border-[#2a2a2a]">
            <div className="bg-[#1a1a1a] p-6 text-white border-b border-[#2a2a2a]">
              <div className="flex items-start gap-4">
                <div className="bg-[#b4ff00]/10 rounded-2xl p-3">
                  <AlertCircle className="w-8 h-8 text-[#b4ff00]" />
                </div>
                <div className="flex-1">
                  <h2 className="text-xl font-bold mb-1">تنبيه مهم</h2>
                  <p className="text-white/90 text-sm">هويتك الوطنية تحتاج للتجديد</p>
                </div>
              </div>
            </div>

            <div className="p-6 space-y-6">
              <div className="flex items-center justify-center gap-4">
                <div className="text-center">
                  <div className="bg-[#2a2a2a] rounded-2xl w-20 h-20 flex items-center justify-center border border-[#3a3a3a]">
                    <span className="text-4xl font-bold text-[#b4ff00]">10</span>
                  </div>
                  <span className="text-gray-400 text-sm mt-2 block">يوم متبقي</span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <Clock className="w-5 h-5 text-[#b4ff00]" />
                  <div className="w-px h-8 bg-[#2a2a2a]"></div>
                </div>
                <div className="text-center">
                  <p className="text-gray-500 text-xs mb-1">تاريخ الانتهاء</p>
                  <p className="text-lg font-semibold text-white">1446/06/15</p>
                  <p className="text-gray-500 text-xs">هـ</p>
                </div>
              </div>

              <div className="bg-[#2a2a2a] rounded-2xl p-4 border border-[#3a3a3a]">
                <div className="flex gap-3">
                  <Sparkles className="w-5 h-5 text-[#b4ff00] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-gray-300 text-sm leading-relaxed">
                      يمكنك الآن تجديد هويتك الوطنية <span className="font-semibold text-[#b4ff00]">تلقائياً</span> بخطوات بسيطة دون الحاجة لزيارة الفرع.
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <Button className="w-full h-14 text-lg font-semibold bg-[#1a3d1a] hover:bg-[#234d23] text-white rounded-2xl">
                  <Sparkles className="w-5 h-5 ml-2" />
                  تفعيل الأتمتة
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Step 2: Approvals */}
        <div className="space-y-4">
          <h2 className="text-2xl font-bold text-white text-center mb-6">الخطوة 2: الخيارات</h2>
          
          {/* Photo Section */}
          <div className="bg-white rounded-3xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center">
                <Camera className="w-6 h-6 text-blue-500" />
              </div>
              <div>
                <h3 className="font-bold text-slate-800">صورة الهوية</h3>
                <p className="text-sm text-slate-500">اختر مصدر الصورة</p>
              </div>
            </div>
            <div className="flex items-center gap-4 p-4 rounded-2xl border-2 border-[#059669] bg-emerald-50/50">
              <div className="w-14 h-14 rounded-xl bg-slate-100 flex items-center justify-center">
                <User className="w-8 h-8 text-slate-400" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-slate-700">استخدام الصورة الحالية</p>
                <p className="text-sm text-slate-500">صورة الهوية المسجلة</p>
              </div>
              <div className="w-6 h-6 rounded-full bg-[#059669] flex items-center justify-center">
                <Check className="w-4 h-4 text-white" />
              </div>
            </div>
          </div>

          {/* Delivery Section */}
          <div className="bg-white rounded-3xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-12 h-12 rounded-2xl bg-purple-50 flex items-center justify-center">
                <MapPin className="w-6 h-6 text-purple-500" />
              </div>
              <div>
                <h3 className="font-bold text-slate-800">طريقة الاستلام</h3>
                <p className="text-sm text-slate-500">كيف تريد استلام هويتك؟</p>
              </div>
            </div>
            <div className="flex items-center gap-4 p-4 rounded-2xl border-2 border-[#059669] bg-emerald-50/50">
              <div className="w-14 h-14 rounded-xl bg-slate-100 flex items-center justify-center">
                <Building2 className="w-7 h-7 text-slate-600" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-slate-700">الاستلام من أقرب فرع</p>
                <p className="text-sm text-slate-500">سيتم تحديد الفرع الأقرب لك</p>
              </div>
              <div className="w-6 h-6 rounded-full bg-[#059669] flex items-center justify-center">
                <Check className="w-4 h-4 text-white" />
              </div>
            </div>
          </div>

          {/* Payment Section */}
          <div className="bg-white rounded-3xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-amber-500" />
              </div>
              <div>
                <h3 className="font-bold text-slate-800">طريقة الدفع</h3>
                <p className="text-sm text-slate-500">اختر وسيلة الدفع المناسبة</p>
              </div>
            </div>
            <div className="flex items-center gap-4 p-4 rounded-2xl border-2 border-[#059669] bg-emerald-50/50">
              <div className="w-14 h-14 rounded-xl bg-slate-100 flex items-center justify-center">
                <CreditCard className="w-7 h-7 text-slate-600" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-slate-700">مدى / بطاقة ائتمانية</p>
                <p className="text-sm text-slate-500">دفع فوري عبر البوابة الإلكترونية</p>
              </div>
              <div className="w-6 h-6 rounded-full bg-[#059669] flex items-center justify-center">
                <Check className="w-4 h-4 text-white" />
              </div>
            </div>
          </div>
        </div>

        {/* Step 3: Progress */}
        <div className="space-y-4">
          <h2 className="text-2xl font-bold text-white text-center mb-6">الخطوة 3: المعالجة</h2>
          <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
            <div className="bg-gradient-to-l from-blue-500 to-indigo-500 p-5 text-white">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                  <Shield className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">الأتمتة نشطة</h3>
                  <p className="text-white/80 text-sm">جاري تنفيذ الخطوات...</p>
                </div>
              </div>
            </div>

            <div className="p-6 space-y-4">
              {[
                { title: 'جمع البيانات', description: 'تم بنجاح', icon: Database, completed: true },
                { title: 'تحميل الوثائق', description: 'تم بنجاح', icon: FileUp, completed: true },
                { title: 'جدولة الموعد', description: 'تم بنجاح', icon: Calendar, completed: true },
                { title: 'في انتظار الدفع', description: 'جاري التنفيذ...', icon: CreditCard, current: true },
              ].map((step, index) => {
                const Icon = step.icon;
                return (
                  <div
                    key={index}
                    className={`flex items-center gap-4 p-4 rounded-2xl ${
                      step.completed ? 'bg-emerald-50' : 
                      step.current ? 'bg-amber-50 border-2 border-amber-200' : 
                      'bg-slate-50'
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      step.completed ? 'bg-[#059669]' :
                      step.current ? 'bg-amber-500' :
                      'bg-slate-200'
                    }`}>
                      {step.completed ? (
                        <Check className="w-6 h-6 text-white" />
                      ) : step.current ? (
                        <Loader2 className="w-6 h-6 text-white animate-spin" />
                      ) : (
                        <Icon className="w-6 h-6 text-slate-400" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className={`font-semibold ${
                        step.completed ? 'text-[#059669]' :
                        step.current ? 'text-amber-700' :
                        'text-slate-400'
                      }`}>
                        {step.title}
                      </p>
                      <p className={`text-sm ${
                        step.completed ? 'text-emerald-600' :
                        step.current ? 'text-amber-600' :
                        'text-slate-400'
                      }`}>
                        {step.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Step 4: Completion */}
        <div className="space-y-4">
          <h2 className="text-2xl font-bold text-white text-center mb-6">الخطوة 4: الإتمام</h2>
          
          <div className="relative overflow-hidden rounded-3xl">
            <div className="bg-gradient-to-l from-[#059669] to-[#10b981] px-6 py-12 text-white text-center">
              <div className="w-24 h-24 bg-white rounded-full mx-auto mb-6 flex items-center justify-center shadow-2xl">
                <PartyPopper className="w-12 h-12 text-[#059669]" />
              </div>
              <h3 className="text-3xl font-bold mb-2">تم بنجاح! 🎉</h3>
              <p className="text-white/90 text-lg">تم تجديد هويتك الوطنية</p>
            </div>
          </div>

          <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
            <div className="p-6 border-b border-slate-100">
              <div className="flex items-center justify-between">
                {[1, 2, 3, 4].map((step, index) => (
                  <React.Fragment key={step}>
                    <div className="w-8 h-8 rounded-full bg-[#059669] text-white flex items-center justify-center">
                      <Check className="w-4 h-4" />
                    </div>
                    {index < 3 && <div className="flex-1 h-1 mx-2 rounded-full bg-[#059669]" />}
                  </React.Fragment>
                ))}
              </div>
              <p className="text-center text-[#059669] font-medium mt-3">جميع الخطوات مكتملة</p>
            </div>

            <div className="p-6 space-y-3">
              <h4 className="font-bold text-slate-800 mb-4">تفاصيل العملية</h4>
              
              <div className="flex items-center justify-between py-3 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
                    <Shield className="w-5 h-5 text-blue-500" />
                  </div>
                  <span className="text-slate-600">رقم المرجع</span>
                </div>
                <span className="font-semibold text-slate-800 font-mono">ID-2024-789456</span>
              </div>
              
              <div className="flex items-center justify-between py-3 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-green-50 flex items-center justify-center">
                    <CreditCard className="w-5 h-5 text-green-500" />
                  </div>
                  <span className="text-slate-600">المبلغ المدفوع</span>
                </div>
                <span className="font-semibold text-[#059669]">100 ريال</span>
              </div>
              
              <div className="flex items-center justify-between py-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center">
                    <MapPin className="w-5 h-5 text-amber-500" />
                  </div>
                  <span className="text-slate-600">فرع الاستلام</span>
                </div>
                <span className="font-semibold text-slate-800 text-sm">فرع الرياض - العليا</span>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center py-8">
          <p className="text-gray-500 text-sm">عرض توضيحي لتطبيق تجديد الهوية الوطنية</p>
        </div>
      </div>
    </div>
  );
}