import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertCircle, Clock, ChevronLeft, Shield, Sparkles, Loader2, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import NotificationBell from '@/components/notifications/NotificationBell';

export default function Notification() {
  const navigate = useNavigate();
  const [showToast, setShowToast] = useState(false);
  const daysRemaining = 10;
  const expiryDate = '1446/06/15';

  useEffect(() => {
    // Show notification toast after a brief delay
    const timer = setTimeout(() => {
      setShowToast(true);
      showNotificationToast();
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  const showNotificationToast = () => {
    toast.custom((t) => (
      <div className="bg-white rounded-3xl shadow-2xl overflow-hidden w-full max-w-md mx-auto" dir="rtl">
        <div className="bg-gradient-to-l from-[#1e3a5f] to-[#2d4a6f] p-4 text-white relative">
          <button
            onClick={() => toast.dismiss(t)}
            className="absolute top-3 left-3 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-3">
            <Shield className="w-12 h-12" />
            <div>
              <h2 className="text-lg font-bold">هلا والله لجين خالد</h2>
              <p className="text-white/80 text-sm">أبشر بوت</p>
            </div>
          </div>
        </div>
        
        <div className="p-4">
          <p className="text-slate-700 text-sm mb-3 text-center">
            حابه يذكرك بقرب انتهاء هويتك
          </p>
          <p className="text-xl font-bold text-[#1e3a5f] mb-3 font-mono text-center" dir="ltr">
            1093447146
          </p>
          <p className="text-slate-600 text-xs mb-4 text-center">
            للتجديد التلقائي، الرجاء الموافقة وقبول الطلب في <span className="font-semibold">نفاذ</span>
          </p>
          
          <div className="space-y-2">
            <Button
              onClick={() => {
                toast.dismiss(t);
                handleApprove();
              }}
              className="w-full h-12 text-sm font-semibold bg-gradient-to-l from-[#059669] to-[#10b981] hover:from-[#047857] hover:to-[#059669] rounded-xl"
            >
              <Shield className="w-4 h-4 ml-2" />
              موافق
            </Button>
            
            <Button
              onClick={() => {
                toast.dismiss(t);
                handleAddToCalendar();
              }}
              variant="outline"
              className="w-full h-10 text-sm border-2 border-slate-200 hover:bg-slate-50 rounded-xl"
            >
              إضافة إلى التقويم
            </Button>
          </div>
        </div>
      </div>
    ), {
      duration: Infinity,
      position: 'top-center',
    });
  };

  const handleApprove = () => {
    const code = Math.floor(10 + Math.random() * 90);
    
    toast.custom((t) => (
      <div className="bg-white rounded-3xl shadow-2xl overflow-hidden w-full max-w-md mx-auto" dir="rtl">
        <div className="bg-gradient-to-l from-[#1e3a5f] to-[#2d4a6f] p-4 text-white">
          <div className="flex items-center gap-3">
            <Shield className="w-10 h-10" />
            <h2 className="text-lg font-bold">رمز التحقق</h2>
          </div>
        </div>
        
        <div className="p-6 text-center">
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-[#059669] rounded-2xl p-6 mb-4">
            <p className="text-slate-600 text-xs mb-2">الرقم على الشاشة</p>
            <p className="text-5xl font-bold text-[#059669] tracking-wider font-mono mb-3">
              {code}
            </p>
            <div className="bg-white rounded-xl p-3 border border-green-200">
              <p className="text-sm text-slate-700 font-semibold">
                اقبل الرقم <span className="font-bold text-[#059669]">{code}</span> بتطبيق نفاذ
              </p>
            </div>
          </div>
          
          <div className="flex items-center justify-center gap-2 text-slate-500 text-xs">
            <div className="w-2 h-2 bg-amber-400 rounded-full animate-pulse" />
            <span>في انتظار الموافقة من نفاذ...</span>
          </div>
        </div>
      </div>
    ), {
      duration: 5000,
      position: 'top-center',
    });

    setTimeout(() => {
      toast.loading('جاري التحقق...', { position: 'top-center' });
      setTimeout(() => {
        toast.dismiss();
        navigate(createPageUrl('Approvals'));
      }, 2000);
    }, 3000);
  };

  const handleAddToCalendar = () => {
    toast.success('تم إضافة التذكير إلى التقويم بنجاح', {
      position: 'top-center',
      duration: 2000,
    });
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a]" dir="rtl">
        {/* Header */}
        <div className="bg-[#0a0a0a] text-white px-6 py-8">
        <div className="max-w-md mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Shield className="w-6 h-6" />
              <span className="font-semibold text-lg">أبشر</span>
            </div>
            <div className="flex items-center gap-3">
              <NotificationBell />
              <span className="text-white/70 text-sm">الخدمات الإلكترونية</span>
            </div>
          </div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center py-4"
          >
            <p className="text-white/80 mb-2">مرحباً بك</p>
            <h1 className="text-2xl font-bold">لجين خالد</h1>
          </motion.div>
        </div>
      </div>

        {/* Main Content */}
        <div className="max-w-md mx-auto px-6 -mt-6">
        {/* Alert Card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ 
            type: "spring",
            stiffness: 260,
            damping: 20,
            delay: 0.1
          }}
          className="bg-[#1a1a1a] rounded-3xl shadow-xl shadow-black/50 overflow-hidden border border-[#2a2a2a]"
        >
          {/* Alert Header */}
          <div className="bg-[#1a1a1a] p-6 text-white border-b border-[#2a2a2a]">
            <div className="flex items-start gap-4">
              <div className="bg-[#b4ff00]/10 rounded-2xl p-3">
                <AlertCircle className="w-8 h-8 text-[#b4ff00]" />
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-bold mb-1">تنبيه مهم</h2>
                <p className="text-white/90 text-sm">هويتك الوطنية تحتاج للتجديد</p>
              </div>
            </div>
          </div>

          {/* Alert Body */}
          <div className="p-6 space-y-6">
            {/* Countdown */}
            <div className="flex items-center justify-center gap-4">
              <div className="text-center">
                <div className="bg-[#2a2a2a] rounded-2xl w-20 h-20 flex items-center justify-center border border-[#3a3a3a]">
                  <span className="text-4xl font-bold text-[#b4ff00]">{daysRemaining}</span>
                </div>
                <span className="text-gray-400 text-sm mt-2 block">يوم متبقي</span>
              </div>
              <div className="flex flex-col items-center gap-1">
                <Clock className="w-5 h-5 text-[#b4ff00]" />
                <div className="w-px h-8 bg-[#2a2a2a]"></div>
              </div>
              <div className="text-center">
                <p className="text-gray-500 text-xs mb-1">تاريخ الانتهاء</p>
                <p className="text-lg font-semibold text-white">{expiryDate}</p>
                <p className="text-gray-500 text-xs">هـ</p>
              </div>
            </div>

            {/* Info Box */}
            <div className="bg-[#2a2a2a] rounded-2xl p-4 border border-[#3a3a3a]">
              <div className="flex gap-3">
                <Sparkles className="w-5 h-5 text-[#b4ff00] flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    يمكنك الآن تجديد هويتك الوطنية <span className="font-semibold text-[#b4ff00]">تلقائياً</span> بخطوات بسيطة دون الحاجة لزيارة الفرع.
                  </p>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3 pt-2">
              <Link to={createPageUrl('Approvals')} className="block">
                <Button 
                  className="w-full h-14 text-lg font-semibold bg-[#1a3d1a] hover:bg-[#234d23] text-white rounded-2xl transition-all duration-300"
                >
                  <Sparkles className="w-5 h-5 ml-2" />
                  تفعيل الأتمتة
                </Button>
              </Link>
              
              <Button 
                variant="ghost" 
                className="w-full h-12 text-gray-400 hover:text-gray-300 hover:bg-[#1a1a1a] rounded-2xl"
              >
                تذكيري لاحقاً
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Footer Info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center mt-8 pb-8"
        >
          <p className="text-gray-500 text-sm">
            رسوم التجديد: <span className="font-semibold text-gray-300">100 ريال</span>
          </p>
        </motion.div>
        </div>
    </div>
  );
}