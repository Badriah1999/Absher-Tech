
import React from 'react';
import NotificationToast from '@/components/notifications/NotificationToast';
import BottomNav from '@/components/navigation/BottomNav';
import { Toaster } from 'sonner';

export default function Layout({ children, currentPageName }) {
  return (
    <div className="min-h-screen pb-20">
      <Toaster position="top-center" richColors />
      <NotificationToast />
      {children}
      <BottomNav />
    </div>
  );
}
